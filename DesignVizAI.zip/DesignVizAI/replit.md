# <coders.h> - The Agentic Programming Tutor

## Overview
<coders.h> is an interactive programming learning platform that helps users master 12 programming languages through gamified challenges, AI-powered tutoring, and spaced repetition learning. Users progress from "Baby Coder" to "The Deity" through 7 mastery levels, completing 50 challenges per level.

## Current State
- **Phase**: Task 1 Complete (Schema & Frontend) - All data models defined, design tokens configured, and complete frontend built
- **Last Updated**: January 2025
- **Status**: Frontend complete with all components and pages implemented

## Project Architecture

### Tech Stack
- **Frontend**: React + TypeScript, Tailwind CSS, Shadcn UI, Wouter (routing), TanStack Query
- **Backend**: Express.js, TypeScript
- **Database**: In-memory storage (MemStorage) - to be implemented with PostgreSQL
- **AI**: OpenAI GPT-5 (4 specialized agents)
- **Styling**: Custom blue gradient color palette (#173753, #6daedb, #2892d7, #1b4353, #1d70a2)

### Data Models (shared/schema.ts)
1. **Users**: Authentication, gamification stats (XP, vigor, streaks, rank), achievements
2. **Languages**: 12 programming languages (Python, C++, Rust, JavaScript, TypeScript, SQL, HTML, CSS, R, Java, Go, C)
3. **Challenges**: 4,200 total (50 × 7 levels × 12 languages) with test cases, hints, Big O targets
4. **UserProgress**: Per-language progress tracking, M-Scores, completed challenges, unlocked levels
5. **ConceptMastery**: Spaced repetition M-Score tracking per concept
6. **Submissions**: Code submission history with test results and complexity analysis
7. **Conversations**: Code-Duo chat history
8. **Leaderboard**: Rankings by XP and streaks (daily/weekly/all-time)

### Frontend Components (client/src/)

#### Pages
- **home.tsx**: Hero section, features grid, 12 language cards, stats, Code-Duo intro
- **login.tsx / signup.tsx**: Authentication with form validation
- **languages.tsx**: Grid of 12 languages with progress bars and completion stats
- **learn.tsx**: Mastery tree with 7 levels (L1-L7), challenge grid, M-Score tracking, Code-Duo messages
- **challenge.tsx**: Code editor (Textarea for now, Monaco to be added), test cases, progressive hints (4 levels), Code-Duo chat panel, submission results
- **search.tsx**: Advanced filtering (language/level/difficulty/concept), real-time search, active filter badges
- **leaderboard.tsx**: Podium for top 3, rankings table, daily/weekly/all-time tabs
- **profile.tsx**: User stats, rank progress, language-specific progress, achievements

#### Components
- **Header.tsx**: Navigation with gamification stats (XP, Vigor, Streaks), user menu, responsive design

### Design System

#### Color Palette (from PDF)
- Primary: #2892d7 (main blue) - HSL: 204 81% 50%
- Secondary: #6daedb (light blue) - HSL: 205 50% 64%
- Accent: #1d70a2 (deep blue) - HSL: 203 82% 37%
- Dark: #173753 - HSL: 208 72% 21%
- Border/Muted: #1b4353 - HSL: 197 67% 22%

#### Custom Animations (index.css)
- **animate-float**: Floating effect (3s ease-in-out)
- **animate-pulse-glow**: Glowing pulse with blue shadow (2s)
- **animate-streak-fire**: Streak fire effect with scaling (1s)
- **animate-shimmer**: Shimmer gradient animation (2s)
- **gradient-blue**: Linear gradient from primary to secondary
- **gradient-blue-dark**: Dark gradient for hero sections

#### Typography
- **Font**: Inter (sans-serif), JetBrains Mono (monospace)
- **Scale**: text-4xl (hero), text-2xl (sections), text-xl (titles), text-base (body)

### Gamification System

#### Rank Progression (7 Ranks)
1. Baby Coder (0 XP)
2. Code Crawler (1,000 XP)
3. Script Scribbler (2,500 XP)
4. Function Forger (5,000 XP)
5. Algorithm Architect (10,000 XP)
6. System Sage (25,000 XP)
7. The Deity (50,000 XP)

#### Mastery Levels (7 Levels per Language)
1. L1: Noob
2. L2: Apprentice
3. L3: Journeyman
4. L4: Pro
5. L5: Master
6. L6: Expert
7. L7: Godlike

#### Mechanics
- **XP**: Earned per challenge completion (10-100 XP based on difficulty)
- **Vigor**: Energy system (5 max, 1 per challenge, regenerates daily)
- **Streaks**: Daily completion tracking with fire animation
- **M-Scores**: Concept mastery tracking (0-100%) for spaced repetition
- **Big O Optimization**: Bonus XP for hitting target time complexity

### AI Agents (To Be Implemented)

1. **Code-Duo**: Adaptive tutor with personality evolution
   - L1-2: Enthusiastic cheerleader
   - L3-4: Consultative guide
   - L5-7: Challenging master

2. **Code Reviewer**: Analyzes code complexity, quality, suggests optimizations

3. **Hint Generator**: 4-level progressive hints
   - Nudge: Gentle direction
   - Concept: Key concept explanation
   - Approach: Strategy breakdown
   - Optimization: Big O hints

4. **Concept Tutor**: Deep explanations and practice problem generation

### Backend API Routes (To Be Implemented)

#### Authentication
- POST /api/auth/signup
- POST /api/auth/login
- POST /api/auth/logout
- GET /api/auth/me

#### Languages
- GET /api/languages
- GET /api/languages/:id

#### Challenges
- GET /api/challenges/:languageId
- GET /api/challenges/:id
- POST /api/challenges/:id/submit
- GET /api/challenges/all (for search)

#### Progress
- GET /api/progress
- GET /api/progress/:languageId
- POST /api/progress/update

#### AI Endpoints
- POST /api/ai/code-duo (chat)
- POST /api/ai/hints (get progressive hints)
- POST /api/ai/review (code review with complexity)
- POST /api/ai/tutor (concept explanations)

#### Leaderboard
- GET /api/leaderboard/:period (daily/weekly/all-time)

#### Search
- GET /api/search?q=...&language=...&level=...&difficulty=...

### Features Requiring Database Seeding

50 challenges per level must be created for each language based on curriculum files:
- Python: AI/ML, Data Science, Backend (from attached curriculum)
- Java: Enterprise, JVM internals (from attached curriculum)
- C++: Performance, Games, Templates (from attached curriculum)
- C: Systems Core, OS kernel (from attached curriculum)
- Rust: Safety, Systems, Ownership (from attached curriculum)
- R: Statistics, Data Analysis (from attached curriculum)
- SQL: Database queries, optimization
- JavaScript/TypeScript: Web development, async patterns
- HTML/CSS: Web structure, styling
- Go: Cloud, concurrency

Each challenge must include:
- Title, description, difficulty
- Starter code template
- Solution code
- Test cases (visible + hidden)
- 4-level hints (Nudge, Concept, Approach, Optimization)
- Target Big O complexity
- Concept tags for M-Score tracking
- XP reward (10-100)
- Vigor cost (1-3)

## User Preferences
- Blue gradient color scheme (#2892d7, #6daedb, #1d70a2)
- Interactive, Duolingo-style gamification
- Comprehensive curriculum from provided files
- 50 questions per level requirement
- All features must be interactable
- AI agents integrated throughout

## Recent Changes
- Defined complete data schema with all 8 models
- Configured blue gradient design tokens in index.css and tailwind.config.ts
- Created all 9 pages (Home, Auth, Languages, Learn, Challenge, Search, Leaderboard, Profile)
- Built Header component with gamification stats
- Implemented custom animations (float, pulse-glow, streak-fire, shimmer)
- Wired up all routes in App.tsx
- Added comprehensive test IDs throughout for testing

## Next Steps
1. **Task 2**: Implement backend with all API routes, seed database with curriculum data, create 4 AI agents
2. **Task 3**: Connect frontend to backend, add loading/error states, test all features
3. Add Monaco code editor for challenges
4. Implement M-Score spaced repetition algorithm
5. Add real-time Code-Duo chat with streaming responses
6. Deploy and test

## Development Guidelines
- Follow blue color palette strictly
- Use Inter font for body, JetBrains Mono for code
- All interactive elements need data-testid attributes
- Maintain gamification mechanics (XP, Vigor, Streaks)
- Code-Duo personality adapts to user level
- 50 challenges per level is non-negotiable
- M-Score drives spaced repetition review suggestions
