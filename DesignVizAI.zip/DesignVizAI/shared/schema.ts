import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with gamification fields
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  displayName: text("display_name").notNull(),
  avatar: text("avatar").default("default"),
  rank: text("rank").notNull().default("Baby Coder"),
  totalXp: integer("total_xp").notNull().default(0),
  currentVigor: integer("current_vigor").notNull().default(5),
  maxVigor: integer("max_vigor").notNull().default(5),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  lastActiveDate: timestamp("last_active_date"),
  achievements: jsonb("achievements").default([]),
  preferences: jsonb("preferences").default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Languages (12 programming languages)
export const languages = pgTable("languages", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  description: text("description").notNull(),
  color: text("color").notNull(),
  totalChallenges: integer("total_challenges").notNull().default(0),
});

// Challenges (50 per level × 7 levels × 12 languages = 4200 challenges)
export const challenges = pgTable("challenges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  languageId: varchar("language_id").notNull().references(() => languages.id),
  level: integer("level").notNull(), // 1-7 (Noob to Godlike)
  title: text("title").notNull(),
  description: text("description").notNull(),
  difficulty: text("difficulty").notNull(), // "easy", "medium", "hard"
  concepts: jsonb("concepts").notNull().default([]), // Array of concept tags
  starterCode: text("starter_code").notNull(),
  solution: text("solution").notNull(),
  testCases: jsonb("test_cases").notNull(), // Array of {input, expectedOutput, hidden}
  hints: jsonb("hints").notNull(), // 4-level hints: Nudge, Concept, Approach, Optimization
  targetComplexity: text("target_complexity").notNull(), // "O(1)", "O(n)", "O(n log n)", etc.
  xpReward: integer("xp_reward").notNull().default(10),
  vigorCost: integer("vigor_cost").notNull().default(1),
  orderIndex: integer("order_index").notNull(), // Position within level (1-50)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// User Progress per language
export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  languageId: varchar("language_id").notNull().references(() => languages.id),
  currentLevel: integer("current_level").notNull().default(1), // 1-7
  xpInLanguage: integer("xp_in_language").notNull().default(0),
  completedChallenges: jsonb("completed_challenges").notNull().default([]), // Array of challenge IDs
  unlockedLevels: jsonb("unlocked_levels").notNull().default([1]), // Array of unlocked level numbers
  mScores: jsonb("m_scores").notNull().default({}), // Object: {concept: score 0-1}
  lastPracticed: timestamp("last_practiced"),
});

// M-Score concept tracking for spaced repetition
export const conceptMastery = pgTable("concept_mastery", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  languageId: varchar("language_id").notNull().references(() => languages.id),
  concept: text("concept").notNull(),
  mScore: integer("m_score").notNull().default(0), // 0-100 (percentage)
  attempts: integer("attempts").notNull().default(0),
  successes: integer("successes").notNull().default(0),
  lastReviewed: timestamp("last_reviewed"),
  nextReview: timestamp("next_review"),
});

// Challenge submissions
export const submissions = pgTable("submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  challengeId: varchar("challenge_id").notNull().references(() => challenges.id),
  code: text("code").notNull(),
  passed: boolean("passed").notNull(),
  testsPassed: integer("tests_passed").notNull(),
  totalTests: integer("total_tests").notNull(),
  detectedComplexity: text("detected_complexity"),
  xpEarned: integer("xp_earned").notNull().default(0),
  timeTaken: integer("time_taken"), // seconds
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
});

// Code-Duo conversations
export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  challengeId: varchar("challenge_id").references(() => challenges.id),
  messages: jsonb("messages").notNull().default([]), // Array of {role, content, timestamp}
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Leaderboard
export const leaderboard = pgTable("leaderboard", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  period: text("period").notNull(), // "daily", "weekly", "all-time"
  xp: integer("xp").notNull(),
  streak: integer("streak").notNull(),
  rank: integer("rank").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertLanguageSchema = createInsertSchema(languages);
export const insertChallengeSchema = createInsertSchema(challenges).omit({ id: true, createdAt: true });
export const insertUserProgressSchema = createInsertSchema(userProgress).omit({ id: true });
export const insertConceptMasterySchema = createInsertSchema(conceptMastery).omit({ id: true });
export const insertSubmissionSchema = createInsertSchema(submissions).omit({ id: true, submittedAt: true });
export const insertConversationSchema = createInsertSchema(conversations).omit({ id: true, createdAt: true });
export const insertLeaderboardSchema = createInsertSchema(leaderboard).omit({ id: true, updatedAt: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertLanguage = z.infer<typeof insertLanguageSchema>;
export type Language = typeof languages.$inferSelect;
export type InsertChallenge = z.infer<typeof insertChallengeSchema>;
export type Challenge = typeof challenges.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;
export type InsertConceptMastery = z.infer<typeof insertConceptMasterySchema>;
export type ConceptMastery = typeof conceptMastery.$inferSelect;
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Submission = typeof submissions.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertLeaderboard = z.infer<typeof insertLeaderboardSchema>;
export type Leaderboard = typeof leaderboard.$inferSelect;

// Additional types for frontend
export type TestCase = {
  input: string;
  expectedOutput: string;
  hidden: boolean;
};

export type HintLevel = {
  level: "Nudge" | "Concept" | "Approach" | "Optimization";
  content: string;
};

export type Message = {
  role: "user" | "assistant";
  content: string;
  timestamp: number;
};

export type Rank = 
  | "Baby Coder"
  | "Code Crawler"
  | "Script Scribbler"
  | "Function Forger"
  | "Algorithm Architect"
  | "System Sage"
  | "The Deity";

export type MasteryLevel = 
  | "L1: Noob"
  | "L2: Apprentice"
  | "L3: Journeyman"
  | "L4: Pro"
  | "L5: Master"
  | "L6: Expert"
  | "L7: Godlike";
