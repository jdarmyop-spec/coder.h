import { 
  type User, 
  type InsertUser,
  type Language,
  type InsertLanguage,
  type Challenge,
  type InsertChallenge,
  type UserProgress,
  type InsertUserProgress,
  type ConceptMastery,
  type InsertConceptMastery,
  type Submission,
  type InsertSubmission,
  type Conversation,
  type InsertConversation,
  type Leaderboard,
  type InsertLeaderboard,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // Languages
  getAllLanguages(): Promise<Language[]>;
  getLanguage(id: string): Promise<Language | undefined>;
  createLanguage(language: InsertLanguage): Promise<Language>;
  
  // Challenges
  getChallengesByLanguage(languageId: string): Promise<Challenge[]>;
  getChallengesByLevel(languageId: string, level: number): Promise<Challenge[]>;
  getChallenge(id: string): Promise<Challenge | undefined>;
  getAllChallenges(): Promise<Challenge[]>;
  createChallenge(challenge: InsertChallenge): Promise<Challenge>;
  
  // User Progress
  getUserProgress(userId: string): Promise<UserProgress[]>;
  getUserProgressByLanguage(userId: string, languageId: string): Promise<UserProgress | undefined>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: string, updates: Partial<UserProgress>): Promise<UserProgress | undefined>;
  
  // Concept Mastery (M-Scores)
  getConceptMastery(userId: string, languageId: string): Promise<ConceptMastery[]>;
  updateConceptMastery(id: string, updates: Partial<ConceptMastery>): Promise<ConceptMastery | undefined>;
  createConceptMastery(mastery: InsertConceptMastery): Promise<ConceptMastery>;
  
  // Submissions
  createSubmission(submission: InsertSubmission): Promise<Submission>;
  getUserSubmissions(userId: string, challengeId?: string): Promise<Submission[]>;
  
  // Conversations
  getConversation(userId: string, challengeId?: string): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: string, messages: any[]): Promise<Conversation | undefined>;
  
  // Leaderboard
  getLeaderboard(period: "daily" | "weekly" | "all-time"): Promise<Leaderboard[]>;
  updateLeaderboard(entry: InsertLeaderboard): Promise<Leaderboard>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private languages: Map<string, Language>;
  private challenges: Map<string, Challenge>;
  private userProgress: Map<string, UserProgress>;
  private conceptMastery: Map<string, ConceptMastery>;
  private submissions: Map<string, Submission>;
  private conversations: Map<string, Conversation>;
  private leaderboard: Map<string, Leaderboard>;

  constructor() {
    this.users = new Map();
    this.languages = new Map();
    this.challenges = new Map();
    this.userProgress = new Map();
    this.conceptMastery = new Map();
    this.submissions = new Map();
    this.conversations = new Map();
    this.leaderboard = new Map();
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      rank: "Baby Coder",
      totalXp: 0,
      currentVigor: 5,
      maxVigor: 5,
      currentStreak: 0,
      longestStreak: 0,
      lastActiveDate: null,
      achievements: [],
      preferences: {},
      createdAt: new Date(),
      avatar: "default",
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...updates };
    this.users.set(id, updated);
    return updated;
  }

  // Languages
  async getAllLanguages(): Promise<Language[]> {
    return Array.from(this.languages.values());
  }

  async getLanguage(id: string): Promise<Language | undefined> {
    return this.languages.get(id);
  }

  async createLanguage(language: InsertLanguage): Promise<Language> {
    this.languages.set(language.id, language as Language);
    return language as Language;
  }

  // Challenges
  async getChallengesByLanguage(languageId: string): Promise<Challenge[]> {
    return Array.from(this.challenges.values()).filter(c => c.languageId === languageId);
  }

  async getChallengesByLevel(languageId: string, level: number): Promise<Challenge[]> {
    return Array.from(this.challenges.values())
      .filter(c => c.languageId === languageId && c.level === level)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getChallenge(id: string): Promise<Challenge | undefined> {
    return this.challenges.get(id);
  }

  async getAllChallenges(): Promise<Challenge[]> {
    return Array.from(this.challenges.values());
  }

  async createChallenge(insertChallenge: InsertChallenge): Promise<Challenge> {
    const id = randomUUID();
    const challenge: Challenge = {
      ...insertChallenge,
      id,
      createdAt: new Date(),
    };
    this.challenges.set(id, challenge);
    return challenge;
  }

  // User Progress
  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(p => p.userId === userId);
  }

  async getUserProgressByLanguage(userId: string, languageId: string): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values())
      .find(p => p.userId === userId && p.languageId === languageId);
  }

  async createUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const id = randomUUID();
    const progress: UserProgress = {
      ...insertProgress,
      id,
      currentLevel: 1,
      xpInLanguage: 0,
      completedChallenges: [],
      unlockedLevels: [1],
      mScores: {},
      lastPracticed: null,
    };
    this.userProgress.set(id, progress);
    return progress;
  }

  async updateUserProgress(id: string, updates: Partial<UserProgress>): Promise<UserProgress | undefined> {
    const progress = this.userProgress.get(id);
    if (!progress) return undefined;
    const updated = { ...progress, ...updates };
    this.userProgress.set(id, updated);
    return updated;
  }

  // Concept Mastery
  async getConceptMastery(userId: string, languageId: string): Promise<ConceptMastery[]> {
    return Array.from(this.conceptMastery.values())
      .filter(m => m.userId === userId && m.languageId === languageId);
  }

  async updateConceptMastery(id: string, updates: Partial<ConceptMastery>): Promise<ConceptMastery | undefined> {
    const mastery = this.conceptMastery.get(id);
    if (!mastery) return undefined;
    const updated = { ...mastery, ...updates };
    this.conceptMastery.set(id, updated);
    return updated;
  }

  async createConceptMastery(insertMastery: InsertConceptMastery): Promise<ConceptMastery> {
    const id = randomUUID();
    const mastery: ConceptMastery = {
      ...insertMastery,
      id,
      mScore: 0,
      attempts: 0,
      successes: 0,
      lastReviewed: null,
      nextReview: null,
    };
    this.conceptMastery.set(id, mastery);
    return mastery;
  }

  // Submissions
  async createSubmission(insertSubmission: InsertSubmission): Promise<Submission> {
    const id = randomUUID();
    const submission: Submission = {
      ...insertSubmission,
      id,
      submittedAt: new Date(),
    };
    this.submissions.set(id, submission);
    return submission;
  }

  async getUserSubmissions(userId: string, challengeId?: string): Promise<Submission[]> {
    return Array.from(this.submissions.values())
      .filter(s => s.userId === userId && (!challengeId || s.challengeId === challengeId));
  }

  // Conversations
  async getConversation(userId: string, challengeId?: string): Promise<Conversation | undefined> {
    return Array.from(this.conversations.values())
      .find(c => c.userId === userId && (!challengeId || c.challengeId === challengeId));
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const conversation: Conversation = {
      ...insertConversation,
      id,
      messages: [],
      createdAt: new Date(),
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async updateConversation(id: string, messages: any[]): Promise<Conversation | undefined> {
    const conversation = this.conversations.get(id);
    if (!conversation) return undefined;
    const updated = { ...conversation, messages };
    this.conversations.set(id, updated);
    return updated;
  }

  // Leaderboard
  async getLeaderboard(period: "daily" | "weekly" | "all-time"): Promise<Leaderboard[]> {
    return Array.from(this.leaderboard.values())
      .filter(l => l.period === period)
      .sort((a, b) => b.xp - a.xp);
  }

  async updateLeaderboard(insertEntry: InsertLeaderboard): Promise<Leaderboard> {
    const existingEntry = Array.from(this.leaderboard.values())
      .find(l => l.userId === insertEntry.userId && l.period === insertEntry.period);

    if (existingEntry) {
      const updated = {
        ...existingEntry,
        ...insertEntry,
        updatedAt: new Date(),
      };
      this.leaderboard.set(existingEntry.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const entry: Leaderboard = {
        ...insertEntry,
        id,
        updatedAt: new Date(),
      };
      this.leaderboard.set(id, entry);
      return entry;
    }
  }
}

export const storage = new MemStorage();
