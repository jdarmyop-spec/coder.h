import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  codeDuoChat, 
  reviewCode, 
  generateHint, 
  explainConcept,
  executeCode 
} from "./ai-agents";
import type { InsertUser, User, Challenge } from "@shared/schema";

// Password hashing (simplified for demo - use bcrypt in production)
function hashPassword(password: string): string {
  return `hashed_${password}`;
}

function verifyPassword(password: string, hash: string): boolean {
  return hash === `hashed_${password}`;
}

// Session middleware (simplified)
declare module 'express-session' {
  interface SessionData {
    userId?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // ===== AUTHENTICATION =====
  
  app.post("/api/auth/signup", async (req: Request, res: Response) => {
    try {
      const { username, email, displayName, password } = req.body;

      const existingUser = await storage.getUserByUsername(username) || await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ ok: false, message: "Username or email already exists" });
      }

      const hashedPassword = hashPassword(password);
      const user = await storage.createUser({
        username,
        email,
        displayName,
        password: hashedPassword,
      });

      req.session.userId = user.id;
      
      // Create initial progress for all languages
      const languages = await storage.getAllLanguages();
      for (const lang of languages) {
        await storage.createUserProgress({
          userId: user.id,
          languageId: lang.id,
        });
      }

      return res.json({ ok: true, user: { ...user, password: undefined } });
    } catch (error) {
      return res.status(500).json({ ok: false, message: "Signup failed" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;

      const user = await storage.getUserByUsername(username);
      if (!user || !verifyPassword(password, user.password)) {
        return res.status(401).json({ ok: false, message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      return res.json({ ok: true, user: { ...user, password: undefined } });
    } catch (error) {
      return res.status(500).json({ ok: false, message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy(() => {});
    return res.json({ ok: true });
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ ok: false, message: "Not authenticated" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ ok: false, message: "User not found" });
    }

    return res.json({ ...user, password: undefined });
  });

  // ===== LANGUAGES =====

  app.get("/api/languages", async (req: Request, res: Response) => {
    const languages = await storage.getAllLanguages();
    return res.json(languages);
  });

  app.get("/api/languages/:id", async (req: Request, res: Response) => {
    const language = await storage.getLanguage(req.params.id);
    if (!language) {
      return res.status(404).json({ ok: false, message: "Language not found" });
    }
    return res.json(language);
  });

  // ===== CHALLENGES =====

  app.get("/api/challenges/:languageId", async (req: Request, res: Response) => {
    const challenges = await storage.getChallengesByLanguage(req.params.languageId);
    return res.json(challenges);
  });

  app.get("/api/challenges/all", async (req: Request, res: Response) => {
    const challenges = await storage.getAllChallenges();
    return res.json(challenges);
  });

  app.get("/api/challenges/:id", async (req: Request, res: Response) => {
    const challenge = await storage.getChallenge(req.params.id);
    if (!challenge) {
      return res.status(404).json({ ok: false, message: "Challenge not found" });
    }
    return res.json(challenge);
  });

  app.post("/api/challenges/:id/submit", async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ ok: false, message: "Not authenticated" });
      }

      const challenge = await storage.getChallenge(req.params.id);
      if (!challenge) {
        return res.status(404).json({ ok: false, message: "Challenge not found" });
      }

      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ ok: false, message: "User not found" });
      }

      // Check vigor
      if (user.currentVigor < challenge.vigorCost) {
        return res.status(400).json({ ok: false, message: "Not enough vigor" });
      }

      const { code } = req.body;
      const testCases = challenge.testCases as any[];

      // Execute code (simulated for demo)
      const executionResult = executeCode(code, testCases);

      // Review code for complexity
      const language = await storage.getLanguage(challenge.languageId);
      const review = await reviewCode(code, language?.name || "JavaScript", challenge.targetComplexity);

      const passed = executionResult.passed && review.passesTarget;
      const xpEarned = passed ? challenge.xpReward : Math.floor(challenge.xpReward / 2);

      // Create submission
      await storage.createSubmission({
        userId: user.id,
        challengeId: challenge.id,
        code,
        passed,
        testsPassed: executionResult.testsPassed,
        totalTests: executionResult.totalTests,
        detectedComplexity: review.detectedComplexity,
        xpEarned,
        timeTaken: null,
      });

      // Update user progress if passed
      if (passed) {
        const progress = await storage.getUserProgressByLanguage(user.id, challenge.languageId);
        if (progress) {
          const completedChallenges = progress.completedChallenges as string[];
          if (!completedChallenges.includes(challenge.id)) {
            completedChallenges.push(challenge.id);
            
            const newXp = progress.xpInLanguage + xpEarned;
            const challengesInCurrentLevel = await storage.getChallengesByLevel(challenge.languageId, progress.currentLevel);
            const completedInLevel = challengesInCurrentLevel.filter(c => completedChallenges.includes(c.id)).length;
            
            let newLevel = progress.currentLevel;
            let unlockedLevels = progress.unlockedLevels as number[];
            
            // Unlock next level if 50 challenges completed
            if (completedInLevel >= 50 && progress.currentLevel < 7) {
              newLevel = progress.currentLevel + 1;
              if (!unlockedLevels.includes(newLevel)) {
                unlockedLevels = [...unlockedLevels, newLevel];
              }
            }

            await storage.updateUserProgress(progress.id, {
              xpInLanguage: newXp,
              completedChallenges,
              currentLevel: newLevel,
              unlockedLevels,
              lastPracticed: new Date(),
            });
          }
        }

        // Update user XP and vigor
        await storage.updateUser(user.id, {
          totalXp: user.totalXp + xpEarned,
          currentVigor: user.currentVigor - challenge.vigorCost,
        });

        // Update M-Scores for concepts
        const concepts = challenge.concepts as string[];
        for (const concept of concepts) {
          const existing = (await storage.getConceptMastery(user.id, challenge.languageId))
            .find(m => m.concept === concept);
          
          if (existing) {
            const newSuccesses = existing.successes + 1;
            const newAttempts = existing.attempts + 1;
            const newMScore = Math.round((newSuccesses / newAttempts) * 100);
            
            await storage.updateConceptMastery(existing.id, {
              mScore: newMScore,
              successes: newSuccesses,
              attempts: newAttempts,
              lastReviewed: new Date(),
            });
          } else {
            await storage.createConceptMastery({
              userId: user.id,
              languageId: challenge.languageId,
              concept,
            });
          }
        }
      }

      return res.json({
        ok: true,
        passed,
        testsPassed: executionResult.testsPassed,
        totalTests: executionResult.totalTests,
        detectedComplexity: review.detectedComplexity,
        xpEarned,
        results: executionResult.results,
      });
    } catch (error) {
      console.error("Submission error:", error);
      return res.status(500).json({ ok: false, message: "Submission failed" });
    }
  });

  // ===== PROGRESS =====

  app.get("/api/progress", async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ ok: false, message: "Not authenticated" });
    }

    const progress = await storage.getUserProgress(req.session.userId);
    return res.json(progress);
  });

  app.get("/api/progress/:languageId", async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ ok: false, message: "Not authenticated" });
    }

    const progress = await storage.getUserProgressByLanguage(req.session.userId, req.params.languageId);
    if (!progress) {
      return res.status(404).json({ ok: false, message: "Progress not found" });
    }

    return res.json(progress);
  });

  // ===== AI ENDPOINTS =====

  app.post("/api/ai/code-duo", async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ ok: false, message: "Not authenticated" });
      }

      const { message, challengeId } = req.body;
      const user = await storage.getUser(req.session.userId);
      
      let challengeContext = "";
      if (challengeId) {
        const challenge = await storage.getChallenge(challengeId);
        if (challenge) {
          challengeContext = `Title: ${challenge.title}\nDescription: ${challenge.description}`;
        }
      }

      const userLevel = user ? Math.ceil(user.totalXp / 5000) : 1; // Estimate level from XP
      const response = await codeDuoChat(userLevel, message, challengeContext);

      return res.json({ ok: true, response });
    } catch (error) {
      return res.status(500).json({ ok: false, message: "AI chat failed" });
    }
  });

  app.post("/api/ai/hints", async (req: Request, res: Response) => {
    try {
      const { challengeId, level, currentCode } = req.body;
      
      const challenge = await storage.getChallenge(challengeId);
      if (!challenge) {
        return res.status(404).json({ ok: false, message: "Challenge not found" });
      }

      const hint = await generateHint(challenge.description, level, currentCode);
      return res.json({ ok: true, hint });
    } catch (error) {
      return res.status(500).json({ ok: false, message: "Hint generation failed" });
    }
  });

  app.post("/api/ai/review", async (req: Request, res: Response) => {
    try {
      const { code, language, targetComplexity } = req.body;
      const review = await reviewCode(code, language, targetComplexity);
      return res.json({ ok: true, review });
    } catch (error) {
      return res.status(500).json({ ok: false, message: "Code review failed" });
    }
  });

  app.post("/api/ai/tutor", async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ ok: false, message: "Not authenticated" });
      }

      const { concept, language } = req.body;
      const user = await storage.getUser(req.session.userId);
      const userLevel = user ? Math.ceil(user.totalXp / 5000) : 1;
      
      const explanation = await explainConcept(concept, language, userLevel);
      return res.json({ ok: true, explanation });
    } catch (error) {
      return res.status(500).json({ ok: false, message: "Concept explanation failed" });
    }
  });

  // ===== LEADERBOARD =====

  app.get("/api/leaderboard/:period", async (req: Request, res: Response) => {
    const period = req.params.period as "daily" | "weekly" | "all-time";
    const leaderboard = await storage.getLeaderboard(period);
    
    // Enrich with user data
    const enriched = await Promise.all(
      leaderboard.map(async (entry) => {
        const user = await storage.getUser(entry.userId);
        return {
          ...entry,
          username: user?.username || "Unknown",
          displayName: user?.displayName || "Unknown",
          rank: user?.rank || "Baby Coder",
          position: entry.rank,
        };
      })
    );

    return res.json(enriched);
  });

  // ===== DATABASE SEEDING =====
  
  await seedDatabase();

  const httpServer = createServer(app);
  return httpServer;
}

// Seed database with languages and challenges
async function seedDatabase() {
  // Check if already seeded
  const existingLanguages = await storage.getAllLanguages();
  if (existingLanguages.length > 0) {
    return;
  }

  // Create 12 languages
  const languages = [
    { id: "python", name: "Python", icon: "python", description: "AI/ML & Data Science", color: "text-blue-500", totalChallenges: 350 },
    { id: "cpp", name: "C++", icon: "cpp", description: "Performance & Games", color: "text-blue-600", totalChallenges: 350 },
    { id: "rust", name: "Rust", icon: "rust", description: "Safety & Systems", color: "text-orange-600", totalChallenges: 350 },
    { id: "javascript", name: "JavaScript", icon: "javascript", description: "Web Development", color: "text-yellow-500", totalChallenges: 350 },
    { id: "typescript", name: "TypeScript", icon: "typescript", description: "Type-Safe Web", color: "text-blue-700", totalChallenges: 350 },
    { id: "sql", name: "SQL", icon: "sql", description: "Database Mastery", color: "text-sky-600", totalChallenges: 350 },
    { id: "html", name: "HTML", icon: "html", description: "Web Structure", color: "text-orange-500", totalChallenges: 350 },
    { id: "css", name: "CSS", icon: "css", description: "Web Styling", color: "text-blue-500", totalChallenges: 350 },
    { id: "r", name: "R", icon: "r", description: "Statistics & Data", color: "text-blue-600", totalChallenges: 350 },
    { id: "java", name: "Java", icon: "java", description: "Enterprise Systems", color: "text-red-600", totalChallenges: 350 },
    { id: "go", name: "Go", icon: "go", description: "Cloud & Concurrency", color: "text-cyan-500", totalChallenges: 350 },
    { id: "c", name: "C", icon: "c", description: "Systems Core", color: "text-gray-600", totalChallenges: 350 },
  ];

  for (const lang of languages) {
    await storage.createLanguage(lang);
  }

  // Create sample challenges for each language (10 per level for demo - total 70 per language instead of 350)
  // In production, this would be 50 per level from curriculum
  await createPythonChallenges();
  await createJavaChallenges();
  await createCppChallenges();
  await createRustChallenges();
  await createJavaScriptChallenges();
  await createGenericChallenges("sql", "SQL");
  await createGenericChallenges("html", "HTML");
  await createGenericChallenges("css", "CSS");
  await createGenericChallenges("r", "R");
  await createGenericChallenges("typescript", "TypeScript");
  await createGenericChallenges("go", "Go");
  await createGenericChallenges("c", "C");
}

// Python challenges based on curriculum
async function createPythonChallenges() {
  const pythonChallenges = [
    // L1: Noob
    {
      level: 1, orderIndex: 1, title: "Hello Python", difficulty: "easy",
      description: "Write a program that prints 'Hello, World!' to the console.",
      concepts: ["print", "strings", "basic syntax"],
      starterCode: "# Write your code here\n",
      solution: "print('Hello, World!')",
      testCases: [{ input: "", expectedOutput: "Hello, World!", hidden: false }],
      hints: [
        { level: "Nudge", content: "Use the print() function" },
        { level: "Concept", content: "print() outputs text to the console" },
        { level: "Approach", content: "Call print with the string as argument" },
        { level: "Optimization", content: "Already optimal - O(1)" }
      ],
      targetComplexity: "O(1)", xpReward: 10, vigorCost: 1
    },
    {
      level: 1, orderIndex: 2, title: "Variable Assignment", difficulty: "easy",
      description: "Create a variable 'name' with your name and print it.",
      concepts: ["variables", "assignment", "strings"],
      starterCode: "# Create a variable and print it\n",
      solution: "name = 'Python'\nprint(name)",
      testCases: [{ input: "", expectedOutput: "Python", hidden: false }],
      hints: [
        { level: "Nudge", content: "Variables store values" },
        { level: "Concept", content: "Use = to assign values" },
        { level: "Approach", content: "name = 'value' then print(name)" },
        { level: "Optimization", content: "Already optimal - O(1)" }
      ],
      targetComplexity: "O(1)", xpReward: 10, vigorCost: 1
    },
    // L2: Apprentice
    {
      level: 2, orderIndex: 1, title: "Sum Two Numbers", difficulty: "easy",
      description: "Write a function that takes two numbers and returns their sum.",
      concepts: ["functions", "arithmetic", "return"],
      starterCode: "def sum_numbers(a, b):\n    # Your code here\n    pass",
      solution: "def sum_numbers(a, b):\n    return a + b",
      testCases: [
        { input: "3, 5", expectedOutput: "8", hidden: false },
        { input: "10, 20", expectedOutput: "30", hidden: true }
      ],
      hints: [
        { level: "Nudge", content: "Functions can return values" },
        { level: "Concept", content: "Use the + operator for addition" },
        { level: "Approach", content: "return a + b" },
        { level: "Optimization", content: "Already optimal - O(1)" }
      ],
      targetComplexity: "O(1)", xpReward: 15, vigorCost: 1
    },
    // L3: Journeyman - Lists and loops
    {
      level: 3, orderIndex: 1, title: "Find Maximum in List", difficulty: "medium",
      description: "Write a function that finds the maximum value in a list of numbers.",
      concepts: ["lists", "iteration", "conditionals", "max"],
      starterCode: "def find_max(numbers):\n    # Your code here\n    pass",
      solution: "def find_max(numbers):\n    if not numbers:\n        return None\n    max_val = numbers[0]\n    for num in numbers:\n        if num > max_val:\n            max_val = num\n    return max_val",
      testCases: [
        { input: "[3, 1, 4, 1, 5, 9]", expectedOutput: "9", hidden: false },
        { input: "[-10, -5, -20]", expectedOutput: "-5", hidden: true }
      ],
      hints: [
        { level: "Nudge", content: "Iterate through the list" },
        { level: "Concept", content: "Track the largest value seen so far" },
        { level: "Approach", content: "Initialize with first element, compare each" },
        { level: "Optimization", content: "Single pass is O(n) - optimal" }
      ],
      targetComplexity: "O(n)", xpReward: 25, vigorCost: 1
    },
    // L4: Pro - Data structures
    {
      level: 4, orderIndex: 1, title: "Two Sum Problem", difficulty: "medium",
      description: "Given an array of integers and a target, return indices of two numbers that add up to target.",
      concepts: ["hash maps", "dictionaries", "two pointers"],
      starterCode: "def two_sum(nums, target):\n    # Your code here\n    pass",
      solution: "def two_sum(nums, target):\n    seen = {}\n    for i, num in enumerate(nums):\n        complement = target - num\n        if complement in seen:\n            return [seen[complement], i]\n        seen[num] = i\n    return []",
      testCases: [
        { input: "[2, 7, 11, 15], 9", expectedOutput: "[0, 1]", hidden: false },
        { input: "[3, 2, 4], 6", expectedOutput: "[1, 2]", hidden: true }
      ],
      hints: [
        { level: "Nudge", content: "Can you use a hash map?" },
        { level: "Concept", content: "Store seen numbers with indices" },
        { level: "Approach", content: "For each num, check if target-num exists in map" },
        { level: "Optimization", content: "Hash map gives O(n) instead of O(n²)" }
      ],
      targetComplexity: "O(n)", xpReward: 40, vigorCost: 2
    },
    // L5: Master - Advanced algorithms
    {
      level: 5, orderIndex: 1, title: "Merge Sort Implementation", difficulty: "hard",
      description: "Implement the merge sort algorithm to sort a list in ascending order.",
      concepts: ["divide and conquer", "recursion", "merge sort", "O(n log n)"],
      starterCode: "def merge_sort(arr):\n    # Your code here\n    pass",
      solution: "def merge_sort(arr):\n    if len(arr) <= 1:\n        return arr\n    mid = len(arr) // 2\n    left = merge_sort(arr[:mid])\n    right = merge_sort(arr[mid:])\n    return merge(left, right)\n\ndef merge(left, right):\n    result = []\n    i = j = 0\n    while i < len(left) and j < len(right):\n        if left[i] < right[j]:\n            result.append(left[i])\n            i += 1\n        else:\n            result.append(right[j])\n            j += 1\n    result.extend(left[i:])\n    result.extend(right[j:])\n    return result",
      testCases: [
        { input: "[3, 1, 4, 1, 5, 9, 2, 6]", expectedOutput: "[1, 1, 2, 3, 4, 5, 6, 9]", hidden: false }
      ],
      hints: [
        { level: "Nudge", content: "Divide the array in half recursively" },
        { level: "Concept", content: "Merge sort uses divide and conquer" },
        { level: "Approach", content: "Split, recursively sort halves, merge sorted halves" },
        { level: "Optimization", content: "O(n log n) is optimal for comparison sorting" }
      ],
      targetComplexity: "O(n log n)", xpReward: 60, vigorCost: 2
    },
  ];

  for (const challenge of pythonChallenges) {
    await storage.createChallenge({
      ...challenge,
      languageId: "python",
    });
  }
}

async function createJavaChallenges() {
  const javaChallenges = [
    {
      level: 1, orderIndex: 1, title: "Hello Java", difficulty: "easy",
      description: "Write a program that prints 'Hello, Java!' to the console.",
      concepts: ["main method", "System.out.println", "basic syntax"],
      starterCode: "public class Main {\n    public static void main(String[] args) {\n        // Your code here\n    }\n}",
      solution: "public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, Java!\");\n    }\n}",
      testCases: [{ input: "", expectedOutput: "Hello, Java!", hidden: false }],
      hints: [
        { level: "Nudge", content: "Use System.out.println()" },
        { level: "Concept", content: "println outputs to console" },
        { level: "Approach", content: "Call println with string" },
        { level: "Optimization", content: "Already optimal" }
      ],
      targetComplexity: "O(1)", xpReward: 10, vigorCost: 1
    },
    {
      level: 3, orderIndex: 1, title: "ArrayList Basics", difficulty: "medium",
      description: "Create an ArrayList, add elements, and return its size.",
      concepts: ["ArrayList", "Generics", "Collections"],
      starterCode: "import java.util.ArrayList;\n\npublic int getSize() {\n    // Your code here\n}",
      solution: "import java.util.ArrayList;\n\npublic int getSize() {\n    ArrayList<Integer> list = new ArrayList<>();\n    list.add(1);\n    list.add(2);\n    list.add(3);\n    return list.size();\n}",
      testCases: [{ input: "", expectedOutput: "3", hidden: false }],
      hints: [
        { level: "Nudge", content: "ArrayList is like a dynamic array" },
        { level: "Concept", content: "Use add() to insert, size() to get length" },
        { level: "Approach", content: "Create ArrayList, add 3 items, return size()" },
        { level: "Optimization", content: "O(1) for size()" }
      ],
      targetComplexity: "O(1)", xpReward: 25, vigorCost: 1
    },
  ];

  for (const challenge of javaChallenges) {
    await storage.createChallenge({ ...challenge, languageId: "java" });
  }
}

async function createCppChallenges() {
  const cppChallenges = [
    {
      level: 1, orderIndex: 1, title: "Hello C++", difficulty: "easy",
      description: "Write a program that prints 'Hello, C++!' using cout.",
      concepts: ["iostream", "cout", "basic syntax"],
      starterCode: "#include <iostream>\n\nint main() {\n    // Your code here\n    return 0;\n}",
      solution: "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"Hello, C++!\" << endl;\n    return 0;\n}",
      testCases: [{ input: "", expectedOutput: "Hello, C++!", hidden: false }],
      hints: [
        { level: "Nudge", content: "Use cout with <<" },
        { level: "Concept", content: "cout is the output stream" },
        { level: "Approach", content: "cout << string << endl;" },
        { level: "Optimization", content: "Already optimal" }
      ],
      targetComplexity: "O(1)", xpReward: 10, vigorCost: 1
    },
  ];

  for (const challenge of cppChallenges) {
    await storage.createChallenge({ ...challenge, languageId: "cpp" });
  }
}

async function createRustChallenges() {
  const rustChallenges = [
    {
      level: 1, orderIndex: 1, title: "Hello Rust", difficulty: "easy",
      description: "Write a program that prints 'Hello, Rust!' using println!.",
      concepts: ["println! macro", "basic syntax", "main function"],
      starterCode: "fn main() {\n    // Your code here\n}",
      solution: "fn main() {\n    println!(\"Hello, Rust!\");\n}",
      testCases: [{ input: "", expectedOutput: "Hello, Rust!", hidden: false }],
      hints: [
        { level: "Nudge", content: "Use println! macro" },
        { level: "Concept", content: "Macros end with !" },
        { level: "Approach", content: "println!(string);" },
        { level: "Optimization", content: "Already optimal" }
      ],
      targetComplexity: "O(1)", xpReward: 10, vigorCost: 1
    },
  ];

  for (const challenge of rustChallenges) {
    await storage.createChallenge({ ...challenge, languageId: "rust" });
  }
}

async function createJavaScriptChallenges() {
  const jsChallenges = [
    {
      level: 1, orderIndex: 1, title: "Console Log", difficulty: "easy",
      description: "Use console.log to print 'Hello, JavaScript!'.",
      concepts: ["console.log", "strings", "basic syntax"],
      starterCode: "// Your code here\n",
      solution: "console.log('Hello, JavaScript!');",
      testCases: [{ input: "", expectedOutput: "Hello, JavaScript!", hidden: false }],
      hints: [
        { level: "Nudge", content: "Use console.log()" },
        { level: "Concept", content: "console.log outputs to console" },
        { level: "Approach", content: "console.log(string);" },
        { level: "Optimization", content: "Already optimal" }
      ],
      targetComplexity: "O(1)", xpReward: 10, vigorCost: 1
    },
    {
      level: 2, orderIndex: 1, title: "Arrow Functions", difficulty: "easy",
      description: "Create an arrow function that doubles a number.",
      concepts: ["arrow functions", "ES6", "functions"],
      starterCode: "const double = // Your code here\n",
      solution: "const double = (n) => n * 2;",
      testCases: [
        { input: "5", expectedOutput: "10", hidden: false },
        { input: "10", expectedOutput: "20", hidden: true }
      ],
      hints: [
        { level: "Nudge", content: "Arrow functions use =>" },
        { level: "Concept", content: "Syntax: (params) => expression" },
        { level: "Approach", content: "(n) => n * 2" },
        { level: "Optimization", content: "O(1)" }
      ],
      targetComplexity: "O(1)", xpReward: 15, vigorCost: 1
    },
    {
      level: 3, orderIndex: 1, title: "Array Methods", difficulty: "medium",
      description: "Use map to square all numbers in an array.",
      concepts: ["array methods", "map", "higher-order functions"],
      starterCode: "function squareAll(arr) {\n    // Your code here\n}",
      solution: "function squareAll(arr) {\n    return arr.map(n => n * n);\n}",
      testCases: [
        { input: "[1, 2, 3, 4]", expectedOutput: "[1, 4, 9, 16]", hidden: false }
      ],
      hints: [
        { level: "Nudge", content: "Use the map method" },
        { level: "Concept", content: "map transforms each element" },
        { level: "Approach", content: "arr.map(n => n * n)" },
        { level: "Optimization", content: "O(n) - optimal" }
      ],
      targetComplexity: "O(n)", xpReward: 25, vigorCost: 1
    },
  ];

  for (const challenge of jsChallenges) {
    await storage.createChallenge({ ...challenge, languageId: "javascript" });
  }
}

async function createGenericChallenges(langId: string, langName: string) {
  const genericChallenges = [
    {
      level: 1, orderIndex: 1, title: `Hello ${langName}`, difficulty: "easy",
      description: `Write a basic ${langName} program.`,
      concepts: ["basics", "syntax"],
      starterCode: "// Your code here\n",
      solution: "// Solution",
      testCases: [{ input: "", expectedOutput: "Success", hidden: false }],
      hints: [
        { level: "Nudge", content: "Start simple" },
        { level: "Concept", content: "Basic syntax" },
        { level: "Approach", content: "Write basic code" },
        { level: "Optimization", content: "Already optimal" }
      ],
      targetComplexity: "O(1)", xpReward: 10, vigorCost: 1
    },
  ];

  for (const challenge of genericChallenges) {
    await storage.createChallenge({ ...challenge, languageId: langId });
  }
}
