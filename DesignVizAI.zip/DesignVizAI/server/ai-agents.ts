import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// Code-Duo: Adaptive AI tutor with personality that evolves based on user level
export async function codeDuoChat(
  userLevel: number,
  message: string,
  challengeContext?: string
): Promise<string> {
  if (!openai) {
    return "Code-Duo is currently unavailable (API key not configured). But keep coding! You've got this! 🚀";
  }

  let systemPrompt = "";
  
  if (userLevel <= 2) {
    systemPrompt = `You are Code-Duo, an enthusiastic and supportive programming tutor for beginners. 
    Use encouraging language, celebrate small wins, and gently guide learners. 
    Be warm, patient, and motivating. Use emojis sparingly but cheerfully.
    Example tone: "Hi there! Ready to conquer another block of code? I was just organizing the memory allocation for our next lesson, and it's looking perfect for you! Let's get that streak going! 🚀"`;
  } else if (userLevel <= 4) {
    systemPrompt = `You are Code-Duo, a consultative programming guide for intermediate developers.
    Provide thoughtful explanations, ask probing questions, and help users think critically.
    Be professional but friendly. Focus on concepts and best practices.
    Example tone: "Good progress! Now let's think about the time complexity here. What happens when the input size doubles?"`;
  } else {
    systemPrompt = `You are Code-Duo, a challenging master for advanced programmers.
    Set high expectations, push for optimal solutions, and don't accept mediocrity.
    Be direct, technical, and demanding. Reference advanced concepts.
    Example tone: "Code Master! A true expert would aim for O(n). This O(n²) solution won't cut it at your level. Don't disappoint the tree. 🌳"`;
  }

  if (challengeContext) {
    systemPrompt += `\n\nCurrent challenge context:\n${challengeContext}`;
  }

  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: message },
    ],
    max_completion_tokens: 500,
  });

  return response.choices[0].message.content || "I'm here to help! What would you like to know?";
}

// Code Reviewer: Analyzes code complexity, quality, and suggests optimizations
export async function reviewCode(
  code: string,
  language: string,
  targetComplexity: string
): Promise<{
  detectedComplexity: string;
  quality: number;
  suggestions: string[];
  passesTarget: boolean;
}> {
  if (!openai) {
    return {
      detectedComplexity: targetComplexity,
      quality: 75,
      suggestions: ["AI review unavailable - API key not configured"],
      passesTarget: true,
    };
  }

  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [
      {
        role: "system",
        content: `You are an expert code reviewer specializing in algorithmic complexity analysis. 
        Analyze the given code and provide:
        1. Detected time complexity (Big O notation)
        2. Code quality score (0-100)
        3. Specific optimization suggestions
        4. Whether it meets the target complexity
        
        Respond with JSON in this format:
        {
          "detectedComplexity": "O(n)",
          "quality": 85,
          "suggestions": ["suggestion 1", "suggestion 2"],
          "passesTarget": true
        }`,
      },
      {
        role: "user",
        content: `Language: ${language}\nTarget Complexity: ${targetComplexity}\n\nCode:\n${code}`,
      },
    ],
    response_format: { type: "json_object" },
    max_completion_tokens: 800,
  });

  return JSON.parse(response.choices[0].message.content || "{}");
}

// Hint Generator: Progressive 4-level hints (Nudge → Optimization)
export async function generateHint(
  challengeDescription: string,
  level: number,
  currentCode?: string
): Promise<string> {
  if (!openai) {
    return "AI hints are currently unavailable (API key not configured). Review the challenge description and test cases for guidance!";
  }

  const hintLevels = [
    "Nudge: Provide a very gentle directional hint without giving away the solution",
    "Concept: Explain the key concept or data structure needed",
    "Approach: Describe the algorithmic approach step-by-step",
    "Optimization: Explain how to achieve the optimal Big O complexity",
  ];

  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [
      {
        role: "system",
        content: `You are a hint generator for programming challenges. Provide a ${hintLevels[level]} hint.
        Be helpful but don't give away the full solution. Encourage learning.`,
      },
      {
        role: "user",
        content: `Challenge: ${challengeDescription}${currentCode ? `\n\nCurrent code:\n${currentCode}` : ""}`,
      },
    ],
    max_completion_tokens: 300,
  });

  return response.choices[0].message.content || "Keep thinking! You're on the right track.";
}

// Concept Tutor: Deep explanations & practice problem generation
export async function explainConcept(
  concept: string,
  language: string,
  userLevel: number
): Promise<{
  explanation: string;
  examples: string[];
  practiceProblems: string[];
}> {
  if (!openai) {
    return {
      explanation: "AI concept explanations are currently unavailable (API key not configured).",
      examples: ["Check online documentation for examples"],
      practiceProblems: ["Practice by solving more challenges"],
    };
  }

  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [
      {
        role: "system",
        content: `You are a concept tutor. Provide a clear explanation of programming concepts tailored to the user's level.
        Level ${userLevel}: ${userLevel <= 2 ? "beginner" : userLevel <= 4 ? "intermediate" : "advanced"}
        
        Respond with JSON:
        {
          "explanation": "detailed explanation",
          "examples": ["example 1", "example 2"],
          "practiceProblems": ["problem 1", "problem 2"]
        }`,
      },
      {
        role: "user",
        content: `Explain the concept of "${concept}" in ${language} for a level ${userLevel} programmer.`,
      },
    ],
    response_format: { type: "json_object" },
    max_completion_tokens: 1000,
  });

  return JSON.parse(response.choices[0].message.content || "{}");
}

// Simple code execution simulator (for demo purposes)
export function executeCode(
  code: string,
  testCases: any[]
): {
  passed: boolean;
  testsPassed: number;
  totalTests: number;
  results: any[];
} {
  // In a real implementation, this would use a sandboxed code execution environment
  // For now, we'll simulate test results
  const results = testCases.map((testCase) => ({
    input: testCase.input,
    expected: testCase.expectedOutput,
    actual: testCase.expectedOutput, // Simulated: assume all pass for demo
    passed: true,
  }));

  const testsPassed = results.filter(r => r.passed).length;
  
  return {
    passed: testsPassed === testCases.length,
    testsPassed,
    totalTests: testCases.length,
    results,
  };
}
