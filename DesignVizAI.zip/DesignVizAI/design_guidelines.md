# Design Guidelines: Designer Data Analytics Platform

## Design Approach
**Reference-Based with System Foundation**
Primary Inspiration: Linear (modern productivity), Figma (designer UX), Observable (data visualization elegance)
Supporting System: Tailwind with custom components focused on data visualization and AI interactions

**Core Principles:**
- Data-first elegance: Visualizations are the hero, interface recedes
- Designer-centric controls: Visual feedback over technical jargon
- AI transparency: Show AI working, not just results
- Export-ready aesthetics: Every view should look portfolio-worthy

## Typography
**Font Stack:**
- Primary: Inter (via Google Fonts CDN)
- Data/Code: JetBrains Mono for data tables and technical details

**Hierarchy:**
- Hero/Page Titles: text-4xl font-bold (36px)
- Section Headers: text-2xl font-semibold (24px)
- Chart Titles: text-xl font-medium (20px)
- Body Text: text-base (16px)
- Data Labels: text-sm font-medium (14px)
- Helper Text: text-xs text-gray-600 (12px)

## Layout System
**Spacing Scale:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 24
- Component padding: p-6 to p-8
- Section spacing: gap-8 to gap-12
- Page margins: px-8 md:px-16

**Grid Structure:**
- Main workspace: 70/30 split (data area / insights panel)
- Chart builder: 3-column grid for chart type selection
- Dashboard view: Responsive masonry grid (1-2-3 columns)

## Component Library

### Navigation
Top bar with logo left, primary actions center (Upload Data, New Visualization), profile right. Height: h-16, glass morphism effect with backdrop blur.

### File Upload Zone
Large dropzone (min-h-64) with dashed border, pulsing animation on drag-over. Icon: upload cloud (Heroicons). Shows file preview cards immediately after upload with column detection chips.

### AI Insights Panel
Fixed right sidebar (w-80) with floating card aesthetic. Auto-expanding insight cards with AI sparkle icon. Includes:
- Data summary section
- Trend detection cards
- Natural language query input with suggestion chips
- "Ask AI" textarea with submit button

### Chart Builder
Left toolbar with visual chart type icons (8 types: line, bar, area, pie, scatter, heatmap, bubble, radar). Selected state with accent border. Center canvas for live preview. Right panel for customization (colors, labels, axis).

### Data Table
Sticky header, alternating row backgrounds, sortable columns with arrow indicators, row hover highlights. Fixed height with smooth scroll. Cell formatting based on data type (numbers right-aligned, dates formatted).

### Visualization Cards
Rounded-xl cards with chart preview, title, metadata chips (date, data source), and action buttons (Share, Export, Edit). Hover: subtle lift shadow transition.

### Export Modal
Large modal with preview area, format selector pills (PNG/SVG/Link), resolution picker, branding toggle. Download button with progress indicator.

### Color Palette Selector
Grid of designer-curated palette swatches (8 palettes × 5 colors each). Popular options: Viridis, Pastel, Bold, Monochrome, Gradient sets.

## Images
**Hero Section:** Full-width gradient mesh background (abstract data visualization aesthetic - flowing lines and nodes). Height: h-96. Overlay: Semi-transparent dark layer with centered hero content.

**Empty States:** Illustrated SVG graphics for:
- No data uploaded (illustration of upload arrow with data nodes)
- No visualizations created (empty chart frame with sparkles)
- AI thinking state (animated dots/pulse)

## Icons
Use Heroicons (via CDN) throughout:
- Upload: cloud-arrow-up
- AI: sparkles, cpu-chip
- Charts: chart-bar, chart-pie
- Actions: share, download, pencil
- Data: table-cells, document-text

## Key Interactions
**AI Query Input:** Expand on focus, show typing indicator when processing, stream results character-by-character

**Chart Preview:** Live updates as user adjusts parameters, smooth transitions between chart types (300ms ease)

**Data Upload:** Progressive disclosure - upload → preview → insights → visualize flow with breadcrumb progress

**Export:** Single-click for quick PNG export, modal for advanced options

## Layout Sections
1. **Hero (h-96):** Gradient background, centered tagline "Transform Data into Design-Ready Insights", CTA buttons (Upload Data, View Demo)
2. **Feature Grid:** 3-column cards showcasing AI Analysis, Chart Builder, Share & Export
3. **Workspace:** Full application interface (appears after data upload)
4. **Footer:** Links, social, newsletter signup with data privacy emphasis