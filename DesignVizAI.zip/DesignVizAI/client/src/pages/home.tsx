import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Code2, 
  Sparkles, 
  Trophy, 
  Flame, 
  Brain, 
  Zap, 
  Target,
  ChevronRight,
  Cpu
} from "lucide-react";
import { SiPython, SiCplusplus, SiRust, SiJavascript, SiTypescript, SiPostgresql, SiHtml5, SiCss3, SiR, SiC, SiGo } from "react-icons/si";
import { DiJava } from "react-icons/di";

const languages = [
  { id: "python", name: "Python", icon: SiPython, color: "text-blue-500", desc: "AI/ML & Data Science" },
  { id: "cpp", name: "C++", icon: SiCplusplus, color: "text-blue-600", desc: "Performance & Games" },
  { id: "rust", name: "Rust", icon: SiRust, color: "text-orange-600", desc: "Safety & Systems" },
  { id: "javascript", name: "JavaScript", icon: SiJavascript, color: "text-yellow-500", desc: "Web Development" },
  { id: "typescript", name: "TypeScript", icon: SiTypescript, color: "text-blue-700", desc: "Type-Safe Web" },
  { id: "sql", name: "SQL", icon: SiPostgresql, color: "text-sky-600", desc: "Database Mastery" },
  { id: "html", name: "HTML", icon: SiHtml5, color: "text-orange-500", desc: "Web Structure" },
  { id: "css", name: "CSS", icon: SiCss3, color: "text-blue-500", desc: "Web Styling" },
  { id: "r", name: "R", icon: SiR, color: "text-blue-600", desc: "Statistics & Data" },
  { id: "java", name: "Java", icon: DiJava, color: "text-red-600", desc: "Enterprise Systems" },
  { id: "go", name: "Go", icon: SiGo, color: "text-cyan-500", desc: "Cloud & Concurrency" },
  { id: "c", name: "C", icon: SiC, color: "text-gray-600", desc: "Systems Core" },
];

const features = [
  {
    icon: Sparkles,
    title: "Code-Duo AI Tutor",
    description: "Adaptive AI personality that evolves with your skill level. From encouraging beginner support to challenging expert feedback.",
    gradient: "from-primary to-secondary"
  },
  {
    icon: Brain,
    title: "M-Score System",
    description: "Spaced repetition intelligence tracks your concept mastery and automatically suggests review challenges for weak topics.",
    gradient: "from-secondary to-accent"
  },
  {
    icon: Target,
    title: "Big O Mastery",
    description: "Not just correct code—optimize it. Earn bonus XP by hitting target time complexity. Master algorithms that matter.",
    gradient: "from-accent to-primary"
  },
  {
    icon: Trophy,
    title: "Gamified Learning",
    description: "50 challenges per level × 7 mastery tiers. Track streaks, earn XP, manage vigor. Climb from Baby Coder to The Deity.",
    gradient: "from-primary to-accent"
  },
];

const stats = [
  { label: "Languages", value: "12+" },
  { label: "Mastery Levels", value: "7" },
  { label: "Challenges", value: "4,200+" },
  { label: "AI Agents", value: "4" },
];

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden gradient-blue-dark py-24 md:py-32">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="flex items-center justify-center gap-2 animate-float">
              <Code2 className="w-16 h-16 text-white drop-shadow-lg" />
              <Cpu className="w-12 h-12 text-white/80 drop-shadow-lg" />
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-white drop-shadow-lg" data-testid="text-hero-title">
              Master Programming from
              <span className="block mt-2 bg-gradient-to-r from-blue-200 to-cyan-200 bg-clip-text text-transparent">
                Noob to Godlike
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-blue-100 max-w-2xl mx-auto" data-testid="text-hero-description">
              Learn 12+ languages through interactive challenges powered by adaptive AI tutoring. 
              Track your journey from <span className="font-bold">Baby Coder</span> to <span className="font-bold">The Deity</span>.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <Link href="/signup">
                <Button 
                  size="lg" 
                  className="bg-white text-primary hover:bg-blue-50 text-lg px-8 h-14 animate-pulse-glow"
                  data-testid="button-start-learning"
                >
                  Start Learning Free
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link href="/languages">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white/50 text-white hover:bg-white/10 backdrop-blur-sm text-lg px-8 h-14"
                  data-testid="button-explore-languages"
                >
                  Explore Languages
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-12">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center" data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className="text-4xl md:text-5xl font-bold text-white drop-shadow-lg">
                    {stat.value}
                  </div>
                  <div className="text-sm text-blue-200 mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4" data-testid="text-features-title">
              The Agentic Programming Tutor
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Powered by 4 specialized AI agents working together to accelerate your learning
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <Card 
                  key={feature.title} 
                  className="hover-elevate border-card-border transition-all"
                  data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-lg bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <CardTitle className="text-2xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Languages Grid */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4" data-testid="text-languages-title">
              12 Languages, Infinite Possibilities
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Each language features 7 mastery levels with 50 challenges per level
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
            {languages.map((lang) => {
              const Icon = lang.icon;
              return (
                <Link key={lang.id} href={`/learn/${lang.id}`}>
                  <Card 
                    className="hover-elevate active-elevate-2 cursor-pointer border-card-border transition-all group"
                    data-testid={`card-language-${lang.id}`}
                  >
                    <CardHeader className="space-y-3">
                      <Icon className={`w-12 h-12 ${lang.color} group-hover:scale-110 transition-transform`} />
                      <div>
                        <CardTitle className="text-xl">{lang.name}</CardTitle>
                        <CardDescription className="text-sm mt-1">
                          {lang.desc}
                        </CardDescription>
                      </div>
                    </CardHeader>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Code-Duo Section */}
      <section className="py-20 bg-background">
        <div className="container px-4">
          <div className="max-w-4xl mx-auto">
            <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
              <CardHeader className="text-center space-y-4 pb-8">
                <div className="flex items-center justify-center gap-3">
                  <Sparkles className="w-10 h-10 text-primary animate-pulse-glow" />
                  <h2 className="text-4xl font-bold">Meet Code-Duo</h2>
                </div>
                <p className="text-xl text-muted-foreground">
                  Your AI programming companion that adapts to your level
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      <Zap className="w-5 h-5 text-primary" />
                      Level 1-2: Cheerleader
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      "Hi, [User]! Ready to conquer another block of code? Let's get that streak to 3 days! 🚀"
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      <Brain className="w-5 h-5 text-accent" />
                      Level 6-7: Master
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      "Code Master [User]! A true expert would aim for O(n). Don't disappoint the tree. 🌳"
                    </p>
                  </div>
                </div>
                <div className="pt-4 text-center">
                  <Link href="/signup">
                    <Button size="lg" className="gradient-blue" data-testid="button-meet-code-duo">
                      Start Your Journey
                      <Sparkles className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-card py-12">
        <div className="container px-4">
          <div className="text-center text-muted-foreground">
            <p className="text-lg font-semibold mb-2">&lt;coders.h&gt;</p>
            <p className="text-sm">Master programming from Noob to Godlike</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
