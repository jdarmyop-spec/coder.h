import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/Header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Medal, Flame, Crown } from "lucide-react";
import type { User } from "@shared/schema";

interface LeaderboardEntry {
  userId: string;
  username: string;
  displayName: string;
  rank: string;
  totalXp: number;
  currentStreak: number;
  position: number;
}

export default function Leaderboard() {
  const [period, setPeriod] = useState<"daily" | "weekly" | "all-time">("all-time");

  const { data: user } = useQuery<User>({ queryKey: ["/api/auth/me"] });
  const { data: leaderboard, isLoading } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard", period],
  });

  const getPodiumIcon = (position: number) => {
    if (position === 1) return <Crown className="w-8 h-8 text-yellow-500" />;
    if (position === 2) return <Medal className="w-7 h-7 text-gray-400" />;
    if (position === 3) return <Medal className="w-6 h-6 text-orange-600" />;
    return null;
  };

  const getRankColor = (rank: string) => {
    if (rank === "The Deity") return "text-yellow-600";
    if (rank === "System Sage") return "text-purple-600";
    if (rank === "Algorithm Architect") return "text-blue-600";
    if (rank === "Function Forger") return "text-green-600";
    return "text-muted-foreground";
  };

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />

      <div className="container px-4 py-12">
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <Trophy className="w-10 h-10 text-primary animate-pulse-glow" />
            <h1 className="text-5xl font-bold" data-testid="text-page-title">
              Leaderboard
            </h1>
          </div>
          <p className="text-xl text-muted-foreground">
            Compete with coders worldwide. Rise through the ranks!
          </p>
        </div>

        <Tabs value={period} onValueChange={(v: any) => setPeriod(v)} className="space-y-8">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="daily" data-testid="tab-daily">Daily</TabsTrigger>
            <TabsTrigger value="weekly" data-testid="tab-weekly">Weekly</TabsTrigger>
            <TabsTrigger value="all-time" data-testid="tab-all-time">All Time</TabsTrigger>
          </TabsList>

          <TabsContent value={period} className="space-y-6">
            {/* Podium - Top 3 */}
            {leaderboard && leaderboard.length >= 3 && (
              <div className="grid md:grid-cols-3 gap-6 mb-12">
                {/* 2nd Place */}
                <Card className="md:mt-8 border-gray-300 hover-elevate">
                  <CardContent className="pt-8 text-center">
                    <div className="flex justify-center mb-4">
                      {getPodiumIcon(2)}
                    </div>
                    <div className="w-20 h-20 rounded-full gradient-blue mx-auto mb-4 flex items-center justify-center text-white font-bold text-3xl">
                      2
                    </div>
                    <h3 className="text-xl font-bold mb-1" data-testid="text-second-place">
                      {leaderboard[1].displayName}
                    </h3>
                    <p className={`text-sm mb-3 ${getRankColor(leaderboard[1].rank)}`}>
                      {leaderboard[1].rank}
                    </p>
                    <div className="flex items-center justify-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Trophy className="w-4 h-4 text-primary" />
                        <span className="font-bold">{leaderboard[1].totalXp.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Flame className="w-4 h-4 text-orange-500" />
                        <span className="font-bold">{leaderboard[1].currentStreak}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* 1st Place */}
                <Card className="border-yellow-500 border-2 hover-elevate">
                  <CardContent className="pt-8 text-center">
                    <div className="flex justify-center mb-4">
                      {getPodiumIcon(1)}
                    </div>
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 mx-auto mb-4 flex items-center justify-center text-white font-bold text-4xl shadow-lg">
                      1
                    </div>
                    <h3 className="text-2xl font-bold mb-1" data-testid="text-first-place">
                      {leaderboard[0].displayName}
                    </h3>
                    <p className={`text-sm mb-3 ${getRankColor(leaderboard[0].rank)}`}>
                      {leaderboard[0].rank}
                    </p>
                    <div className="flex items-center justify-center gap-4">
                      <div className="flex items-center gap-1">
                        <Trophy className="w-5 h-5 text-primary" />
                        <span className="font-bold text-lg">{leaderboard[0].totalXp.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Flame className="w-5 h-5 text-orange-500" />
                        <span className="font-bold text-lg">{leaderboard[0].currentStreak}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* 3rd Place */}
                <Card className="md:mt-8 border-orange-300 hover-elevate">
                  <CardContent className="pt-8 text-center">
                    <div className="flex justify-center mb-4">
                      {getPodiumIcon(3)}
                    </div>
                    <div className="w-20 h-20 rounded-full gradient-blue mx-auto mb-4 flex items-center justify-center text-white font-bold text-3xl">
                      3
                    </div>
                    <h3 className="text-xl font-bold mb-1" data-testid="text-third-place">
                      {leaderboard[2].displayName}
                    </h3>
                    <p className={`text-sm mb-3 ${getRankColor(leaderboard[2].rank)}`}>
                      {leaderboard[2].rank}
                    </p>
                    <div className="flex items-center justify-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Trophy className="w-4 h-4 text-primary" />
                        <span className="font-bold">{leaderboard[2].totalXp.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Flame className="w-4 h-4 text-orange-500" />
                        <span className="font-bold">{leaderboard[2].currentStreak}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Rest of Leaderboard */}
            <Card>
              <CardHeader>
                <CardTitle>Top Coders</CardTitle>
                <CardDescription>
                  {period === "daily" ? "Today's" : period === "weekly" ? "This week's" : "All-time"} rankings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {leaderboard?.slice(3).map((entry) => (
                    <div
                      key={entry.userId}
                      className={`flex items-center justify-between p-4 rounded-lg hover-elevate ${
                        user?.id === entry.userId ? 'bg-primary/10 border border-primary/30' : 'bg-muted/50'
                      }`}
                      data-testid={`row-user-${entry.position}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full gradient-blue flex items-center justify-center text-white font-bold">
                          {entry.position}
                        </div>
                        <div>
                          <p className="font-bold text-lg">{entry.displayName}</p>
                          <p className={`text-sm ${getRankColor(entry.rank)}`}>
                            {entry.rank}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                          <Trophy className="w-5 h-5 text-primary" />
                          <span className="font-bold">{entry.totalXp.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Flame className="w-5 h-5 text-orange-500" />
                          <span className="font-bold">{entry.currentStreak}</span>
                        </div>
                      </div>
                    </div>
                  ))}

                  {(!leaderboard || leaderboard.length === 0) && (
                    <div className="text-center py-12 text-muted-foreground">
                      <Trophy className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p className="text-lg">No rankings yet. Be the first!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
