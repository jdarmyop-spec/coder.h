import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/Header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Flame, Heart, Code2, Target, TrendingUp, Award } from "lucide-react";
import type { User, UserProgress, Language } from "@shared/schema";

export default function Profile() {
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/auth/me"],
  });

  const { data: progressData, isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress"],
    enabled: !!user,
  });

  const { data: languages } = useQuery<Language[]>({
    queryKey: ["/api/languages"],
  });

  const isLoading = userLoading || progressLoading;

  const getRankProgress = () => {
    if (!user) return 0;
    const ranks = [
      { name: "Baby Coder", xp: 0 },
      { name: "Code Crawler", xp: 1000 },
      { name: "Script Scribbler", xp: 2500 },
      { name: "Function Forger", xp: 5000 },
      { name: "Algorithm Architect", xp: 10000 },
      { name: "System Sage", xp: 25000 },
      { name: "The Deity", xp: 50000 },
    ];

    const currentRankIndex = ranks.findIndex(r => r.name === user.rank);
    if (currentRankIndex === -1 || currentRankIndex === ranks.length - 1) return 100;

    const currentRank = ranks[currentRankIndex];
    const nextRank = ranks[currentRankIndex + 1];
    const progress = ((user.totalXp - currentRank.xp) / (nextRank.xp - currentRank.xp)) * 100;
    
    return Math.min(100, Math.max(0, progress));
  };

  const getNextRankXp = () => {
    if (!user) return 0;
    const ranks = [
      { name: "Baby Coder", xp: 0 },
      { name: "Code Crawler", xp: 1000 },
      { name: "Script Scribbler", xp: 2500 },
      { name: "Function Forger", xp: 5000 },
      { name: "Algorithm Architect", xp: 10000 },
      { name: "System Sage", xp: 25000 },
      { name: "The Deity", xp: 50000 },
    ];

    const currentRankIndex = ranks.findIndex(r => r.name === user.rank);
    if (currentRankIndex === ranks.length - 1) return 0;
    
    return ranks[currentRankIndex + 1].xp - user.totalXp;
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={user} />
        <div className="container px-4 py-12">
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />

      <div className="container px-4 py-12">
        {/* Profile Header */}
        <div className="mb-12">
          <div className="flex items-start gap-6 mb-8">
            <div className="w-32 h-32 rounded-full gradient-blue flex items-center justify-center text-white text-5xl font-bold">
              {user.displayName.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1">
              <h1 className="text-5xl font-bold mb-2" data-testid="text-display-name">
                {user.displayName}
              </h1>
              <p className="text-2xl text-primary mb-4" data-testid="text-rank">
                {user.rank}
              </p>
              <div className="flex items-center gap-6 text-muted-foreground">
                <span data-testid="text-username">@{user.username}</span>
                <span>•</span>
                <span data-testid="text-email">{user.email}</span>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <Trophy className="w-10 h-10 text-primary" />
                  <span className="text-3xl font-bold" data-testid="stat-total-xp">
                    {user.totalXp.toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Total XP</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <Flame className="w-10 h-10 text-orange-500 animate-streak-fire" />
                  <span className="text-3xl font-bold" data-testid="stat-current-streak">
                    {user.currentStreak}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Day Streak</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <TrendingUp className="w-10 h-10 text-green-500" />
                  <span className="text-3xl font-bold" data-testid="stat-longest-streak">
                    {user.longestStreak}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Longest Streak</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <Heart className="w-10 h-10 text-red-500" />
                  <span className="text-3xl font-bold" data-testid="stat-vigor">
                    {user.currentVigor}/{user.maxVigor}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Vigor</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Rank Progress */}
        <Card className="mb-8 border-primary/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-6 h-6 text-primary" />
              Rank Progress
            </CardTitle>
            <CardDescription>
              {getNextRankXp() > 0 
                ? `${getNextRankXp().toLocaleString()} XP needed for next rank`
                : "You've reached the highest rank!"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={getRankProgress()} className="h-4" />
          </CardContent>
        </Card>

        {/* Language Progress */}
        <Tabs defaultValue="languages" className="space-y-6">
          <TabsList>
            <TabsTrigger value="languages">Languages</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="languages" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {progressData?.map((progress) => {
                const language = languages?.find(l => l.id === progress.languageId);
                const completedCount = (progress.completedChallenges as string[]).length;
                const totalChallenges = language?.totalChallenges || 350;
                const completionPercent = Math.round((completedCount / totalChallenges) * 100);

                return (
                  <Card key={progress.id} className="hover-elevate" data-testid={`card-lang-progress-${language?.id}`}>
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <CardTitle className="text-xl">{language?.name}</CardTitle>
                        <Badge variant="secondary">L{progress.currentLevel}</Badge>
                      </div>
                      <CardDescription>
                        {completedCount}/{totalChallenges} challenges
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium">{completionPercent}%</span>
                        </div>
                        <Progress value={completionPercent} className="h-2" />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Trophy className="w-4 h-4 text-primary" />
                          <span className="text-sm font-medium">{progress.xpInLanguage} XP</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Target className="w-4 h-4 text-accent" />
                          <span className="text-sm">{Object.keys(progress.mScores as Record<string, number>).length} concepts</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {(!progressData || progressData.length === 0) && (
              <Card>
                <CardContent className="py-12 text-center">
                  <Code2 className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                  <p className="text-lg font-medium mb-2">No progress yet</p>
                  <p className="text-muted-foreground">Start learning to see your progress here</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="achievements">
            <Card>
              <CardHeader>
                <CardTitle>Achievements</CardTitle>
                <CardDescription>Unlock badges by completing challenges and mastering concepts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  {(user.achievements as any[] || []).map((achievement: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-4 border rounded-lg hover-elevate"
                      data-testid={`achievement-${idx}`}
                    >
                      <div className="text-4xl mb-2">{achievement.icon}</div>
                      <p className="font-bold">{achievement.name}</p>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                    </div>
                  ))}

                  {(!user.achievements || (user.achievements as any[]).length === 0) && (
                    <div className="col-span-3 text-center py-12 text-muted-foreground">
                      <Award className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>No achievements yet. Complete challenges to earn badges!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
