import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/Header";
import { Skeleton } from "@/components/ui/skeleton";
import { SiPython, SiCplusplus, SiRust, SiJavascript, SiTypescript, SiPostgresql, SiHtml5, SiCss3, SiR, SiC, SiGo } from "react-icons/si";
import { DiJava } from "react-icons/di";
import { Trophy, Lock, CheckCircle2 } from "lucide-react";
import type { Language, User, UserProgress } from "@shared/schema";

const languageIcons: Record<string, any> = {
  python: SiPython,
  cpp: SiCplusplus,
  rust: SiRust,
  javascript: SiJavascript,
  typescript: SiTypescript,
  sql: SiPostgresql,
  html: SiHtml5,
  css: SiCss3,
  r: SiR,
  java: DiJava,
  go: SiGo,
  c: SiC,
};

export default function Languages() {
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/auth/me"],
  });

  const { data: languages, isLoading: languagesLoading } = useQuery<Language[]>({
    queryKey: ["/api/languages"],
  });

  const { data: progressData, isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress"],
    enabled: !!user,
  });

  const isLoading = userLoading || languagesLoading || progressLoading;

  const getProgress = (languageId: string) => {
    if (!progressData) return null;
    return progressData.find(p => p.languageId === languageId);
  };

  const getCompletionPercent = (languageId: string) => {
    const progress = getProgress(languageId);
    if (!progress) return 0;
    const totalChallenges = 350; // 50 challenges × 7 levels
    const completed = (progress.completedChallenges as string[]).length;
    return Math.round((completed / totalChallenges) * 100);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />

      <div className="container px-4 py-12">
        <div className="mb-12">
          <h1 className="text-5xl font-bold mb-4" data-testid="text-page-title">
            Choose Your Language
          </h1>
          <p className="text-xl text-muted-foreground">
            Master 12 programming languages through 7 levels of challenges
          </p>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 12 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-12 w-12 rounded-md mb-4" />
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-4 w-full mt-2" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-2 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {languages?.map((lang) => {
              const Icon = languageIcons[lang.id];
              const progress = getProgress(lang.id);
              const completionPercent = getCompletionPercent(lang.id);
              const currentLevel = progress?.currentLevel || 1;
              const completed = progress ? (progress.completedChallenges as string[]).length : 0;

              return (
                <Link key={lang.id} href={`/learn/${lang.id}`}>
                  <Card 
                    className="hover-elevate active-elevate-2 cursor-pointer h-full"
                    data-testid={`card-language-${lang.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <Icon className={`w-14 h-14 ${lang.color}`} />
                        {progress && completed > 0 && (
                          <Badge variant="secondary" className="gap-1">
                            <Trophy className="w-3 h-3" />
                            L{currentLevel}
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="text-2xl">{lang.name}</CardTitle>
                      <CardDescription className="text-base">
                        {lang.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium">{completionPercent}%</span>
                        </div>
                        <Progress value={completionPercent} className="h-2" />
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          {completed > 0 ? (
                            <CheckCircle2 className="w-4 h-4 text-primary" />
                          ) : (
                            <Lock className="w-4 h-4 text-muted-foreground" />
                          )}
                          <span className="text-muted-foreground">
                            {completed}/{lang.totalChallenges} challenges
                          </span>
                        </div>
                        {progress && (
                          <span className="text-primary font-medium">
                            {progress.xpInLanguage} XP
                          </span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
