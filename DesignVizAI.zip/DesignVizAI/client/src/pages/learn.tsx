import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/Header";
import { Skeleton } from "@/components/ui/skeleton";
import { Lock, CheckCircle2, Circle, Trophy, Sparkles, ChevronRight, Target } from "lucide-react";
import type { Language, User, UserProgress, Challenge } from "@shared/schema";

const MASTERY_LEVELS = [
  { level: 1, name: "L1: Noob", color: "text-gray-500", bgColor: "bg-gray-100 dark:bg-gray-900" },
  { level: 2, name: "L2: Apprentice", color: "text-green-600", bgColor: "bg-green-50 dark:bg-green-950" },
  { level: 3, name: "L3: Journeyman", color: "text-blue-600", bgColor: "bg-blue-50 dark:bg-blue-950" },
  { level: 4, name: "L4: Pro", color: "text-purple-600", bgColor: "bg-purple-50 dark:bg-purple-950" },
  { level: 5, name: "L5: Master", color: "text-orange-600", bgColor: "bg-orange-50 dark:bg-orange-950" },
  { level: 6, name: "L6: Expert", color: "text-red-600", bgColor: "bg-red-50 dark:bg-red-950" },
  { level: 7, name: "L7: Godlike", color: "text-yellow-600", bgColor: "bg-yellow-50 dark:bg-yellow-950" },
];

export default function Learn() {
  const { languageId } = useParams<{ languageId: string }>();

  const { data: user } = useQuery<User>({ queryKey: ["/api/auth/me"] });
  const { data: language, isLoading: langLoading } = useQuery<Language>({
    queryKey: ["/api/languages", languageId],
  });
  const { data: progress } = useQuery<UserProgress>({
    queryKey: ["/api/progress", languageId],
    enabled: !!user,
  });
  const { data: challenges, isLoading: challengesLoading } = useQuery<Challenge[]>({
    queryKey: ["/api/challenges", languageId],
  });

  const isLoading = langLoading || challengesLoading;

  const getChallengesByLevel = (level: number) => {
    return challenges?.filter(c => c.level === level) || [];
  };

  const isLevelUnlocked = (level: number) => {
    if (!progress) return level === 1;
    return (progress.unlockedLevels as number[]).includes(level);
  };

  const getLevelProgress = (level: number) => {
    if (!progress) return 0;
    const levelChallenges = getChallengesByLevel(level);
    const completed = levelChallenges.filter(c => 
      (progress.completedChallenges as string[]).includes(c.id)
    ).length;
    return levelChallenges.length > 0 ? Math.round((completed / levelChallenges.length) * 100) : 0;
  };

  const getCodeDuoMessage = () => {
    if (!progress) return "Ready to start your journey? Let's conquer Level 1 together! 🚀";
    const currentLevel = progress.currentLevel;
    if (currentLevel <= 2) {
      return `Great work! You're making amazing progress on Level ${currentLevel}. Keep that streak going! ✨`;
    } else if (currentLevel <= 4) {
      return `Level ${currentLevel} challenges await! You're becoming quite the developer. Let's push forward! 💪`;
    } else if (currentLevel <= 6) {
      return `Impressive! Level ${currentLevel} is where masters are made. Show me what you've got! 🌟`;
    } else {
      return `Code Master! Level 7 awaits. Only the elite reach this height. Don't disappoint the tree. 🌳`;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={user} />
        <div className="container px-4 py-12">
          <Skeleton className="h-12 w-64 mb-8" />
          <div className="space-y-6">
            {Array.from({ length: 7 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-8 w-48" />
                  <Skeleton className="h-4 w-full mt-2" />
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />

      <div className="container px-4 py-12">
        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <Trophy className="w-10 h-10 text-primary" />
            <h1 className="text-5xl font-bold" data-testid="text-page-title">
              {language?.name} Mastery Path
            </h1>
          </div>
          <p className="text-xl text-muted-foreground mb-6">
            Complete 50 challenges per level to unlock the next tier
          </p>

          {/* Code-Duo Message */}
          <Card className="border-primary/30 bg-gradient-to-r from-card to-primary/5">
            <CardContent className="flex items-start gap-4 p-6">
              <Sparkles className="w-8 h-8 text-primary flex-shrink-0 animate-pulse-glow" />
              <div>
                <p className="font-semibold text-lg mb-1">Code-Duo says:</p>
                <p className="text-muted-foreground">{getCodeDuoMessage()}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Mastery Tree */}
        <div className="space-y-6 max-w-5xl mx-auto">
          {MASTERY_LEVELS.map((masteryLevel) => {
            const levelChallenges = getChallengesByLevel(masteryLevel.level);
            const isUnlocked = isLevelUnlocked(masteryLevel.level);
            const progressPercent = getLevelProgress(masteryLevel.level);
            const completed = progress ? levelChallenges.filter(c => 
              (progress.completedChallenges as string[]).includes(c.id)
            ).length : 0;

            return (
              <Card 
                key={masteryLevel.level}
                className={`${isUnlocked ? 'hover-elevate' : 'opacity-60'} transition-all ${masteryLevel.bgColor}`}
                data-testid={`card-level-${masteryLevel.level}`}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-16 h-16 rounded-full ${isUnlocked ? 'gradient-blue' : 'bg-muted'} flex items-center justify-center text-white font-bold text-2xl`}>
                        {isUnlocked ? (
                          progressPercent === 100 ? (
                            <CheckCircle2 className="w-10 h-10" />
                          ) : (
                            masteryLevel.level
                          )
                        ) : (
                          <Lock className="w-8 h-8" />
                        )}
                      </div>
                      <div>
                        <CardTitle className={`text-2xl ${masteryLevel.color}`}>
                          {masteryLevel.name}
                        </CardTitle>
                        <CardDescription className="text-base mt-1">
                          {completed}/{levelChallenges.length} challenges completed
                        </CardDescription>
                      </div>
                    </div>

                    {isUnlocked && (
                      <Badge variant="secondary" className="text-lg px-4 py-2">
                        {progressPercent}%
                      </Badge>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <Progress value={isUnlocked ? progressPercent : 0} className="h-3" />

                  {isUnlocked ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                      {levelChallenges.slice(0, 10).map((challenge, idx) => {
                        const isCompleted = progress ? (progress.completedChallenges as string[]).includes(challenge.id) : false;
                        
                        return (
                          <Link key={challenge.id} href={`/challenge/${challenge.id}`}>
                            <Button
                              variant={isCompleted ? "default" : "outline"}
                              size="sm"
                              className="w-full gap-2"
                              data-testid={`button-challenge-${challenge.id}`}
                            >
                              {isCompleted ? (
                                <CheckCircle2 className="w-4 h-4" />
                              ) : (
                                <Circle className="w-4 h-4" />
                              )}
                              #{idx + 1}
                            </Button>
                          </Link>
                        );
                      })}
                      {levelChallenges.length > 10 && (
                        <Button variant="ghost" size="sm" className="w-full">
                          +{levelChallenges.length - 10} more
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Lock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p className="font-medium">Complete Level {masteryLevel.level - 1} to unlock</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* M-Score Section */}
        {progress && (progress.mScores as Record<string, number>) && Object.keys(progress.mScores as Record<string, number>).length > 0 && (
          <div className="mt-12 max-w-5xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-6 h-6 text-primary" />
                  Concept Mastery (M-Scores)
                </CardTitle>
                <CardDescription>
                  Track your understanding of key programming concepts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {Object.entries(progress.mScores as Record<string, number>).map(([concept, score]) => (
                    <div key={concept} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">{concept}</span>
                        <span className="text-muted-foreground">{Math.round(score * 100)}%</span>
                      </div>
                      <Progress value={score * 100} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
