import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/Header";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Filter, X, Target, Trophy } from "lucide-react";
import type { Challenge, User, Language } from "@shared/schema";

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState<string>("all");
  const [selectedLevel, setSelectedLevel] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");

  const { data: user } = useQuery<User>({ queryKey: ["/api/auth/me"] });
  const { data: languages } = useQuery<Language[]>({ queryKey: ["/api/languages"] });
  const { data: allChallenges } = useQuery<Challenge[]>({
    queryKey: ["/api/challenges/all"],
  });

  const filteredChallenges = allChallenges?.filter(challenge => {
    const matchesSearch = searchQuery.trim() === "" || 
      challenge.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      challenge.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (challenge.concepts as string[]).some(c => c.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesLanguage = selectedLanguage === "all" || challenge.languageId === selectedLanguage;
    const matchesLevel = selectedLevel === "all" || challenge.level.toString() === selectedLevel;
    const matchesDifficulty = selectedDifficulty === "all" || challenge.difficulty === selectedDifficulty;

    return matchesSearch && matchesLanguage && matchesLevel && matchesDifficulty;
  });

  const activeFilters = [
    selectedLanguage !== "all" && { type: "language", value: selectedLanguage },
    selectedLevel !== "all" && { type: "level", value: `Level ${selectedLevel}` },
    selectedDifficulty !== "all" && { type: "difficulty", value: selectedDifficulty },
  ].filter(Boolean);

  const clearFilter = (type: string) => {
    if (type === "language") setSelectedLanguage("all");
    if (type === "level") setSelectedLevel("all");
    if (type === "difficulty") setSelectedDifficulty("all");
  };

  const clearAllFilters = () => {
    setSelectedLanguage("all");
    setSelectedLevel("all");
    setSelectedDifficulty("all");
    setSearchQuery("");
  };

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />

      <div className="container px-4 py-12">
        <div className="mb-12">
          <h1 className="text-5xl font-bold mb-4" data-testid="text-page-title">
            Search Challenges
          </h1>
          <p className="text-xl text-muted-foreground">
            Find specific topics, concepts, or technologies across all languages and levels
          </p>
        </div>

        {/* Search and Filters */}
        <div className="space-y-6 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search by title, description, or concept..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-base"
              data-testid="input-search"
            />
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-muted-foreground" />
              <span className="text-sm font-medium">Filters:</span>
            </div>

            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-48" data-testid="select-language">
                <SelectValue placeholder="All Languages" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Languages</SelectItem>
                {languages?.map(lang => (
                  <SelectItem key={lang.id} value={lang.id}>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger className="w-40" data-testid="select-level">
                <SelectValue placeholder="All Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                {[1, 2, 3, 4, 5, 6, 7].map(level => (
                  <SelectItem key={level} value={level.toString()}>
                    Level {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger className="w-40" data-testid="select-difficulty">
                <SelectValue placeholder="All Difficulties" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Difficulties</SelectItem>
                <SelectItem value="easy">Easy</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="hard">Hard</SelectItem>
              </SelectContent>
            </Select>

            {activeFilters.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={clearAllFilters}
                data-testid="button-clear-filters"
              >
                Clear All
              </Button>
            )}
          </div>

          {/* Active Filter Badges */}
          {activeFilters.length > 0 && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-muted-foreground">Active:</span>
              {activeFilters.map((filter: any) => (
                <Badge
                  key={filter.type}
                  variant="secondary"
                  className="gap-2"
                  data-testid={`badge-filter-${filter.type}`}
                >
                  {filter.value}
                  <X
                    className="w-3 h-3 cursor-pointer hover:text-destructive"
                    onClick={() => clearFilter(filter.type)}
                  />
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Results */}
        <div className="mb-6">
          <p className="text-muted-foreground" data-testid="text-results-count">
            Found {filteredChallenges?.length || 0} challenge{filteredChallenges?.length !== 1 ? 's' : ''}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredChallenges?.map(challenge => {
            const language = languages?.find(l => l.id === challenge.languageId);
            
            return (
              <Link key={challenge.id} href={`/challenge/${challenge.id}`}>
                <Card 
                  className="hover-elevate active-elevate-2 h-full cursor-pointer"
                  data-testid={`card-challenge-${challenge.id}`}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline">{language?.name}</Badge>
                      <Badge variant="secondary">L{challenge.level}</Badge>
                    </div>
                    <CardTitle className="text-xl line-clamp-2">
                      {challenge.title}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {challenge.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <Badge className={
                        challenge.difficulty === "easy" ? "bg-green-500" :
                        challenge.difficulty === "medium" ? "bg-yellow-500" :
                        "bg-red-500"
                      }>
                        {challenge.difficulty}
                      </Badge>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <Trophy className="w-4 h-4 text-primary" />
                          <span>{challenge.xpReward}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Target className="w-4 h-4 text-accent" />
                          <span className="font-mono text-xs">{challenge.targetComplexity}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {(challenge.concepts as string[]).slice(0, 3).map(concept => (
                        <Badge key={concept} variant="outline" className="text-xs">
                          {concept}
                        </Badge>
                      ))}
                      {(challenge.concepts as string[]).length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{(challenge.concepts as string[]).length - 3}
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        {filteredChallenges?.length === 0 && (
          <Card className="py-12">
            <CardContent className="text-center">
              <Search className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
              <p className="text-xl font-medium mb-2">No challenges found</p>
              <p className="text-muted-foreground">Try adjusting your search or filters</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
