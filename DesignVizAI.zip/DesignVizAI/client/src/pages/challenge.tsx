import { useParams } from "wouter";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Header } from "@/components/Header";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  Play, 
  Lightbulb, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  Trophy,
  Heart,
  Clock,
  Target
} from "lucide-react";
import type { Challenge, User, Submission } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function ChallengePage() {
  const { challengeId } = useParams<{ challengeId: string }>();
  const { toast } = useToast();
  const [code, setCode] = useState("");
  const [activeHintLevel, setActiveHintLevel] = useState(0);
  const [testResults, setTestResults] = useState<any>(null);

  const { data: user } = useQuery<User>({ queryKey: ["/api/auth/me"] });
  const { data: challenge, isLoading } = useQuery<Challenge>({
    queryKey: ["/api/challenges", challengeId],
  });

  const submitMutation = useMutation({
    mutationFn: async (submissionCode: string) => {
      return await apiRequest("POST", `/api/challenges/${challengeId}/submit`, {
        code: submissionCode,
      });
    },
    onSuccess: (result) => {
      setTestResults(result);
      if (result.passed) {
        toast({
          title: "Challenge Completed! 🎉",
          description: `You earned ${result.xpEarned} XP!`,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      } else {
        toast({
          title: "Tests Failed",
          description: `${result.testsPassed}/${result.totalTests} tests passed`,
          variant: "destructive",
        });
      }
    },
  });

  const requestHintMutation = useMutation({
    mutationFn: async (level: number) => {
      return await apiRequest("POST", `/api/ai/hints`, {
        challengeId,
        level,
        currentCode: code,
      });
    },
    onSuccess: (result) => {
      toast({
        title: `Hint Level ${activeHintLevel + 1}`,
        description: result.hint,
      });
    },
  });

  if (isLoading || !challenge) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={user} />
        <div className="container px-4 py-8">
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  const hints = challenge.hints as any[];
  const testCases = challenge.testCases as any[];

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />

      <div className="container px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left: Challenge Description */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary">Level {challenge.level}</Badge>
                  <Badge className={
                    challenge.difficulty === "easy" ? "bg-green-500" :
                    challenge.difficulty === "medium" ? "bg-yellow-500" :
                    "bg-red-500"
                  }>
                    {challenge.difficulty}
                  </Badge>
                </div>
                <CardTitle className="text-2xl" data-testid="text-challenge-title">
                  {challenge.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground whitespace-pre-wrap">
                  {challenge.description}
                </p>

                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-primary" />
                    <span>{challenge.xpReward} XP</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span>{challenge.vigorCost} Vigor</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-accent" />
                    <span>{challenge.targetComplexity}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {(challenge.concepts as string[]).map((concept) => (
                    <Badge key={concept} variant="outline" className="text-xs">
                      {concept}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Hints */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-500" />
                  Progressive Hints
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {hints.map((hint, idx) => (
                  <div key={idx}>
                    {activeHintLevel >= idx ? (
                      <div className="p-3 bg-muted rounded-md text-sm">
                        <p className="font-medium mb-1">{hint.level}:</p>
                        <p className="text-muted-foreground">{hint.content}</p>
                      </div>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={() => {
                          setActiveHintLevel(idx + 1);
                          requestHintMutation.mutate(idx);
                        }}
                        data-testid={`button-hint-${idx}`}
                      >
                        Unlock {hint.level} Hint
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Code-Duo Chat */}
            <Card className="border-primary/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary animate-pulse-glow" />
                  Code-Duo
                </CardTitle>
                <CardDescription>Ask for help or guidance</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Ask Code-Duo anything about this challenge..."
                  className="min-h-24"
                  data-testid="input-code-duo-chat"
                />
                <Button className="w-full mt-3 gradient-blue" data-testid="button-send-message">
                  Send Message
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right: Code Editor & Tests */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Code Editor</CardTitle>
                <CardDescription>
                  Write your solution below. Target complexity: <span className="font-bold text-primary">{challenge.targetComplexity}</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={code || challenge.starterCode}
                  onChange={(e) => setCode(e.target.value)}
                  className="font-mono text-sm min-h-96 resize-none"
                  placeholder="// Write your code here..."
                  data-testid="input-code-editor"
                />
                
                <div className="flex items-center gap-3 mt-4">
                  <Button
                    className="gradient-blue gap-2"
                    onClick={() => submitMutation.mutate(code || challenge.starterCode)}
                    disabled={submitMutation.isPending || !user || (user.currentVigor < challenge.vigorCost)}
                    data-testid="button-run-tests"
                  >
                    <Play className="w-4 h-4" />
                    {submitMutation.isPending ? "Running..." : "Run Tests"}
                  </Button>
                  
                  {user && user.currentVigor < challenge.vigorCost && (
                    <p className="text-sm text-destructive">Not enough vigor!</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Test Results */}
            {testResults && (
              <Card className={testResults.passed ? "border-green-500" : "border-red-500"}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {testResults.passed ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-green-500" />
                        All Tests Passed!
                      </>
                    ) : (
                      <>
                        <XCircle className="w-6 h-6 text-red-500" />
                        Tests Failed
                      </>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      Passed: {testResults.testsPassed}/{testResults.totalTests}
                    </span>
                    <Progress value={(testResults.testsPassed / testResults.totalTests) * 100} className="w-48 h-2" />
                  </div>

                  {testResults.detectedComplexity && (
                    <div className="flex items-center gap-2">
                      <Target className="w-5 h-5 text-accent" />
                      <span className="text-sm">
                        Detected Complexity: <span className="font-mono font-bold">{testResults.detectedComplexity}</span>
                      </span>
                    </div>
                  )}

                  {testResults.passed && testResults.xpEarned > 0 && (
                    <div className="flex items-center gap-2 text-primary font-medium">
                      <Trophy className="w-5 h-5" />
                      <span>+{testResults.xpEarned} XP Earned!</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Test Cases */}
            <Card>
              <CardHeader>
                <CardTitle>Test Cases</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {testCases.filter(tc => !tc.hidden).map((testCase, idx) => (
                    <div key={idx} className="p-3 bg-muted rounded-md font-mono text-sm" data-testid={`test-case-${idx}`}>
                      <div className="flex items-start gap-2">
                        <span className="text-muted-foreground">Input:</span>
                        <code className="flex-1">{testCase.input}</code>
                      </div>
                      <div className="flex items-start gap-2 mt-1">
                        <span className="text-muted-foreground">Output:</span>
                        <code className="flex-1">{testCase.expectedOutput}</code>
                      </div>
                    </div>
                  ))}
                  {testCases.some(tc => tc.hidden) && (
                    <p className="text-sm text-muted-foreground italic">
                      + {testCases.filter(tc => tc.hidden).length} hidden test case(s)
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
