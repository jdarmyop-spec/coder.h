import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Flame, Trophy, Heart, Search, Menu, User, LogOut } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  user?: {
    displayName: string;
    totalXp: number;
    currentVigor: number;
    maxVigor: number;
    currentStreak: number;
    rank: string;
  };
  onLogout?: () => void;
}

export function Header({ user, onLogout }: HeaderProps) {
  const [location, setLocation] = useLocation();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link href="/">
            <a className="flex items-center gap-2 hover-elevate px-3 py-2 rounded-md transition-all" data-testid="link-home">
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                &lt;coders.h&gt;
              </span>
            </a>
          </Link>

          {user && (
            <nav className="hidden md:flex items-center gap-2">
              <Link href="/languages">
                <Button
                  variant={location === "/languages" ? "default" : "ghost"}
                  size="sm"
                  data-testid="button-languages"
                >
                  Languages
                </Button>
              </Link>
              <Link href="/search">
                <Button
                  variant={location === "/search" ? "default" : "ghost"}
                  size="sm"
                  data-testid="button-search"
                >
                  <Search className="w-4 h-4 mr-1" />
                  Search
                </Button>
              </Link>
              <Link href="/leaderboard">
                <Button
                  variant={location === "/leaderboard" ? "default" : "ghost"}
                  size="sm"
                  data-testid="button-leaderboard"
                >
                  <Trophy className="w-4 h-4 mr-1" />
                  Leaderboard
                </Button>
              </Link>
            </nav>
          )}
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <>
              <div className="hidden lg:flex items-center gap-4">
                <div className="flex items-center gap-2" data-testid="stat-streak">
                  <Flame className="w-5 h-5 text-orange-500 animate-streak-fire" />
                  <span className="font-bold text-lg">{user.currentStreak}</span>
                  <span className="text-sm text-muted-foreground">day streak</span>
                </div>

                <div className="flex items-center gap-2" data-testid="stat-xp">
                  <Trophy className="w-5 h-5 text-primary" />
                  <span className="font-bold text-lg">{user.totalXp.toLocaleString()}</span>
                  <span className="text-sm text-muted-foreground">XP</span>
                </div>

                <div className="flex flex-col gap-1" data-testid="stat-vigor">
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span className="text-sm font-medium">
                      {user.currentVigor}/{user.maxVigor}
                    </span>
                  </div>
                  <Progress
                    value={(user.currentVigor / user.maxVigor) * 100}
                    className="w-24 h-2"
                  />
                </div>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" data-testid="button-user-menu">
                    <User className="w-5 h-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium" data-testid="text-username">{user.displayName}</p>
                    <p className="text-xs text-muted-foreground" data-testid="text-rank">{user.rank}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <a className="w-full" data-testid="link-profile">
                        <User className="w-4 h-4 mr-2" />
                        Profile
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onLogout} data-testid="button-logout">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/login">
                <Button variant="ghost" size="sm" data-testid="button-login">
                  Login
                </Button>
              </Link>
              <Link href="/signup">
                <Button size="sm" className="gradient-blue" data-testid="button-signup">
                  Sign Up
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
